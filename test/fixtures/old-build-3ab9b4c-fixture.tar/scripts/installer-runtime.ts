import { createHash } from 'node:crypto';
import { mkdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';

import { executableCommand } from '../src/executable.ts';
export const powershellVersion = '7.6.6';
const powershellHash = '02fe458be20493fbdf43f61ea20610b811ee6c738ab1676c61b9cfcd1a33c860';

export async function run(command: string[], cwd: string): Promise<void> {
	const child = Bun.spawn(executableCommand(command), {
		cwd,
		stdout: 'inherit',
		stderr: 'inherit',
		stdin: 'ignore',
		windowsHide: true,
	});
	if ((await child.exited) !== 0) throw new Error(`Failed: ${command[0]}`);
}

export async function stagePowerShell(cache: string, destination: string): Promise<void> {
	await mkdir(cache, { recursive: true });
	const archive = join(cache, `PowerShell-${powershellVersion}-win-x64.zip`);
	if (!(await Bun.file(archive).exists())) {
		const response = await fetch(
			`https://github.com/PowerShell/PowerShell/releases/download/v${powershellVersion}/PowerShell-${powershellVersion}-win-x64.zip`,
		);
		if (!response.ok) throw new Error(`PowerShell download failed: ${response.status}`);
		await Bun.write(archive, response);
	}
	const digest = createHash('sha256')
		.update(await readFile(archive))
		.digest('hex');
	if (digest !== powershellHash) throw new Error('PowerShell archive checksum mismatch.');
	await mkdir(destination, { recursive: true });
	await run(['tar.exe', '-xf', archive, '-C', destination], cache);
}
