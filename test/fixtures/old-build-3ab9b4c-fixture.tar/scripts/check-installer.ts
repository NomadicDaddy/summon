import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { z } from 'zod';

const payload = resolve(process.argv[2] ?? '');
if (!process.argv[2]) throw new Error('Provide the installer payload directory.');
const manifest = z
	.object({
		bun: z.string(),
		powershell: z.string(),
		files: z.array(z.object({ path: z.string(), sha256: z.string(), bytes: z.number() })),
	})
	.parse(JSON.parse(await readFile(join(payload, 'installer-build.json'), 'utf8')));
for (const file of manifest.files) {
	const path = resolve(payload, file.path);
	if (!path.startsWith(`${payload}\\`)) throw new Error('Manifest path escapes payload.');
	const content = await readFile(path);
	if (
		content.length !== file.bytes ||
		createHash('sha256').update(content).digest('hex') !== file.sha256
	)
		throw new Error(`Payload mismatch: ${file.path}`);
}
const probeRoot = resolve(import.meta.dir, '../dist/installer-checks', crypto.randomUUID());
const environment: Record<string, string | undefined> = {
	...process.env,
	PATH: join(process.env.SystemRoot ?? 'C:\\Windows', 'System32'),
	SUMMON_HOME: join(probeRoot, 'store'),
};
// Windows children can retain both spellings; either one must carry the restricted value.
environment.Path = environment.PATH;
// Only the disposable probe child is isolated; the invoking named session is untouched.
delete environment.SUMMON_AGENT;
delete environment.SUMMON_NONCE;
delete environment.SUMMON_TEAMS_HOME;
await mkdir(environment.SUMMON_HOME ?? '', { recursive: true });
async function probe(command: string[], expected: string): Promise<void> {
	const child = Bun.spawn(command, {
		cwd: payload,
		env: environment,
		windowsHide: true,
		stdout: 'pipe',
		stderr: 'pipe',
		stdin: 'ignore',
	});
	const timeout = setTimeout(() => child.kill(), 30_000);
	try {
		const [stdout, stderr, code] = await Promise.all([
			new Response(child.stdout).text(),
			new Response(child.stderr).text(),
			child.exited,
		]);
		if (code !== 0 || !stdout.includes(expected))
			throw new Error(`Payload probe failed (${code}): ${stderr}\n${stdout}`);
	} finally {
		clearTimeout(timeout);
	}
}
const bun = join(payload, 'runtime/bun/bun.exe');
await probe(
	[
		bun,
		'-e',
		`if (process.env.PATH !== ${JSON.stringify(environment.PATH)}) throw new Error('Bun PATH isolation failed'); console.log('system-only-path');`,
	],
	'system-only-path',
);
await probe([bun, '--version'], manifest.bun);
await probe([bun, join(payload, 'app/src/cli.ts'), '--help'], 'summon <name>');
await probe(
	[
		join(payload, 'runtime/pwsh/pwsh.exe'),
		'-NoProfile',
		'-NonInteractive',
		'-Command',
		`$allowed = @('${environment.PATH?.replaceAll("'", "''")}', $PSHOME); if (@($env:PATH.Split([IO.Path]::PathSeparator) | Where-Object { $_ -notin $allowed }).Count -gt 0) { throw 'PowerShell PATH isolation failed' }; $PSVersionTable.PSVersion.ToString()`,
	],
	manifest.powershell,
);
const nativeProbe = join(probeRoot, 'native-probe.cjs');
await writeFile(
	nativeProbe,
	`
const { createRequire } = require('node:module');
if (process.env.PATH !== ${JSON.stringify(environment.PATH)}) throw new Error('Electron PATH isolation failed');
const load = createRequire(${JSON.stringify(join(payload, 'app/package.json'))});
const pty = load('node-pty').spawn(process.env.COMSPEC, ['/d', '/c', 'echo summon-native-ready'], {
  name: 'xterm-color', cols: 80, rows: 24, cwd: process.cwd(), env: process.env,
});
let output = '';
pty.onData(data => { output += data; });
pty.onExit(({ exitCode }) => {
  console.log(output);
  process.exit(exitCode === 0 && output.includes('summon-native-ready') ? 0 : 1);
});
setTimeout(() => { pty.kill(); process.exit(1); }, 10000).unref();
`,
);
await probe(
	[
		bun,
		'-e',
		`
const child = Bun.spawn([${JSON.stringify(join(payload, 'app/node_modules/electron/dist/electron.exe'))}, ${JSON.stringify(nativeProbe)}], {
  env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, windowsHide: true,
  stdout: 'inherit', stderr: 'inherit', stdin: 'ignore',
}); process.exit(await child.exited);
`,
	],
	'summon-native-ready',
);
console.log(
	`Verified ${manifest.files.length} payload hashes; bundled Bun, PowerShell, CLI and Electron/node-pty probes passed with verified restricted PATH.`,
);
