import { join } from 'node:path';

import { codexCompactionReader } from './codex-compaction-history.ts';
import { requireExecutable } from './executable.ts';
import { optionalText } from './mail-files.ts';
import { deliveryStatus, runtimePath, saveDelivery } from './mail-session.ts';
import { startMailWatcher } from './mail-watcher.ts';
import { assertNotificationOpen, NotificationNotSentError } from './notification-delivery.ts';

export async function queueCodex(thread: string, text: string): Promise<void> {
	if (!/^[a-zA-Z0-9_-]{8,128}$/.test(thread))
		throw new NotificationNotSentError('An exact Codex thread ID is required.');
	let executable: string;
	try {
		executable = requireExecutable('codex');
	} catch (error: unknown) {
		throw new NotificationNotSentError('Codex executable is unavailable.', { cause: error });
	}
	await assertNotificationOpen();
	const child = Bun.spawn({
		cmd: [executable, 'queue', '--thread', thread, '--message', text],
		stdin: 'ignore',
		stdout: 'ignore',
		stderr: 'ignore',
		windowsHide: true,
	});
	const timeout = setTimeout(() => child.kill(), 15000);
	try {
		const code = await child.exited;
		if (code !== 0)
			throw new Error(`Codex queue failed (exit ${code}); check the provider session.`);
	} finally {
		clearTimeout(timeout);
	}
}

export function waitForCodexBinding(
	name: string,
	nonce: string,
	resumedThread?: string,
): () => Promise<void> {
	let stopped = false;
	let cleanup: (() => Promise<void>) | undefined;
	let pending: Promise<void> | undefined;
	const observeCompactions = codexCompactionReader(name, nonce);
	const poll = async (): Promise<void> => {
		if (stopped) return;
		if (cleanup) {
			await observeCompactions();
			return;
		}
		const thread =
			(await optionalText(join(runtimePath(name), `${nonce}.binding`))) ?? resumedThread;
		if (!thread) return;
		await saveDelivery(name, { ...(await deliveryStatus(name, nonce)), thread });
		cleanup = await startMailWatcher(name, nonce, async (text) => {
			const current =
				(await optionalText(join(runtimePath(name), `${nonce}.binding`))) ?? resumedThread;
			if (!current)
				throw new NotificationNotSentError('Codex thread binding is unavailable.');
			const status = await deliveryStatus(name, nonce);
			if (status.thread !== current) await saveDelivery(name, { ...status, thread: current });
			await queueCodex(current, text);
		});
		await observeCompactions();
	};
	const timer = setInterval(() => {
		if (!pending)
			pending = poll()
				.catch((error: unknown) => console.error('Codex mail:', error))
				.finally(() => {
					pending = undefined;
				});
	}, 500);
	return async () => {
		stopped = true;
		clearInterval(timer);
		await pending;
		// Bound shutdown work; a later launch replays remaining metadata with native-ID deduplication.
		let complete = false;
		for (let count = 0; count < 8 && !complete; count++) complete = await observeCompactions();
		if (!complete)
			console.error(
				'Codex compaction backfill remains incomplete; it can resume on the next launch.',
			);
		await cleanup?.();
	};
}
