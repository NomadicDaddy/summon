import { join } from 'node:path';

import type { CheckpointPackage } from './checkpoint-package-model.ts';
import type { WakePart } from './wake-part.ts';

import { checkpointHash, parseCheckpointState } from './checkpoint-package-model.ts';
import { checkpointStatePath } from './checkpoint-package-store.ts';
import { ownHolds } from './mail-attention.ts';
import { atomicWrite, missing, optionalText } from './mail-files.ts';
import { ownMailbox } from './mail-identity.ts';
import { header, statePath } from './mail-read.ts';
import { runtimePath } from './mail-session.ts';
import { pendingMessages } from './mailbox.ts';
import { restReadyNotice } from './rest.ts';
import { wakeTargetRead } from './wake-read-proof.ts';

export function deliveryNotice(
	name: string,
	nonce: string,
	introduced: boolean,
	mailCount: number,
	decisionCount: number,
): string {
	if (!introduced)
		return [
			`summon mailbox readiness: run summon --mail ready ${nonce}.`,
			'Then use summon --mail receive for your own pending mail and summon --mail holds for approval decisions.',
			'This is a transport check, not approval to perform requests.',
		].join(' ');
	if (decisionCount > 0 && mailCount === 0)
		return `summon: ${decisionCount} approval decision(s) for ${name}. At the next safe checkpoint run summon --mail holds. Act only inside an approved proposal.`;
	if (decisionCount > 0)
		return `summon: ${mailCount} new mail item(s) and ${decisionCount} approval decision(s) for ${name}. At the next safe checkpoint run summon --mail receive and summon --mail holds. Assess, confirm, act or hold; only user approval releases holds.`;
	return `summon: ${mailCount} new mailbox event(s) for ${name}. At the next safe boundary read summon --current-requests --format text before historical catch-up, then use summon-receive. Assess, confirm, act or hold; only user approval releases holds.`;
}

const attemptsPath = (name: string, nonce: string): string =>
	join(runtimePath(name), `${nonce}.attempts`);
async function seen(name: string, nonce: string): Promise<Set<string>> {
	ownMailbox(name);
	return new Set(
		((await optionalText(attemptsPath(name, nonce))) ?? '').split('\n').filter(Boolean),
	);
}
async function markKeys(
	name: string,
	nonce: string,
	keys: string[],
	deferred: boolean,
): Promise<void> {
	const values = await seen(name, nonce);
	for (const key of keys) {
		if (deferred) values.delete(key);
		else values.add(key);
	}
	await atomicWrite(attemptsPath(name, nonce), [...values].join('\n'));
}

export async function prepareReadiness(
	name: string,
	nonce: string,
	reminder = false,
): Promise<WakePart | undefined> {
	ownMailbox(name);
	const acknowledged = async (): Promise<boolean> =>
		(await optionalText(join(runtimePath(name), `${nonce}.ready`))) === nonce;
	if ((await acknowledged()) || (!reminder && (await seen(name, nonce)).has('ready')))
		return undefined;
	return {
		target: { source: 'readiness', key: nonce, through: 0, ids: [] },
		text: deliveryNotice(name, nonce, false, 0, 0),
		needed: async () => !(await acknowledged()),
		acknowledged,
		mark: async (state) => {
			await markKeys(name, nonce, ['ready'], state === 'deferred');
		},
	};
}

export async function prepareMailNotice(
	name: string,
	nonce: string,
	packet?: CheckpointPackage,
): Promise<WakePart | undefined> {
	const previous = await seen(name, nonce);
	const covered = new Set(
		packet?.items.filter((item) => item.source === 'mail').map((item) => item.id),
	);
	const ids: string[] = [];
	const rest: string[] = [];
	for (const file of await pendingMessages(name)) {
		const id = file.slice(0, -3);
		if (!/^[0-9a-f-]{36}$/.test(id) || previous.has(id) || covered.has(id)) continue;
		const mail = await header(name, id).catch((error: unknown) => {
			if (missing(error)) return undefined;
			throw error;
		});
		if (
			!mail ||
			mail.kind === 'receipt' ||
			mail.noticeStatus === 'obsolete' ||
			(await optionalText(statePath(name, id, 'read')))
		)
			continue;
		ids.push(id);
		const notice = await restReadyNotice(name, mail.from, id);
		if (notice) rest.push(notice);
	}
	if (!ids.length) return undefined;
	const acknowledged = async (): Promise<boolean> =>
		(
			await Promise.all(
				ids.map(async (id) => !!(await optionalText(statePath(name, id, 'read')))),
			)
		).every(Boolean);
	return {
		target: { source: 'mail', key: 'inbox', through: 0, ids },
		text: [...rest, deliveryNotice(name, nonce, true, ids.length, 0)].join('\n'),
		needed: async () => {
			const pending = new Set(await pendingMessages(name));
			return (
				await Promise.all(
					ids.map(async (id) => {
						if (
							!pending.has(`${id}.md`) ||
							(await optionalText(statePath(name, id, 'read')))
						)
							return false;
						const current = await header(name, id).catch((error: unknown) => {
							if (missing(error)) return undefined;
							throw error;
						});
						return !!current && current.noticeStatus !== 'obsolete';
					}),
				)
			).some(Boolean);
		},
		acknowledged,
		mark: async (state) => {
			await markKeys(name, nonce, ids, state === 'deferred');
		},
	};
}

export async function prepareHoldNotice(
	name: string,
	nonce: string,
	packet?: CheckpointPackage,
): Promise<WakePart | undefined> {
	const previous = await seen(name, nonce);
	const state = parseCheckpointState(await optionalText(checkpointStatePath(name)));
	const holds = (await ownHolds(name))
		.filter(
			(hold) =>
				hold.decision !== 'pending' &&
				!previous.has(`hold:${hold.id}:${hold.decision}`) &&
				packet?.sources.holds[hold.id] !== checkpointHash(hold) &&
				state.seenHolds[hold.id] !== checkpointHash(hold),
		)
		.sort((a, b) => a.id.localeCompare(b.id));
	if (!holds.length) return undefined;
	const keys = holds.map((hold) => `hold:${hold.id}:${hold.decision}`);
	const target = {
		source: 'holds' as const,
		key: 'decisions',
		through: 0,
		ids: holds.map((hold) => `hold:${hold.id}:${checkpointHash(hold)}`),
	};
	return {
		target,
		text: deliveryNotice(name, nonce, true, 0, keys.length),
		needed: async () => {
			const current = new Set(
				(await ownHolds(name)).map((hold) => `hold:${hold.id}:${hold.decision}`),
			);
			return keys.some((key) => current.has(key));
		},
		// Decision storage is not read coverage; only the frozen package final receipt covers it.
		acknowledged: async () => wakeTargetRead(name, nonce, target),
		mark: async (state) => {
			await markKeys(name, nonce, keys, state === 'deferred');
		},
	};
}
