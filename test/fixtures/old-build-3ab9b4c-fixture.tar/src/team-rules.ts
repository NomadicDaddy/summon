import { readFileSync } from 'node:fs';
import { join } from 'node:path';

import { storageRoot } from './store.ts';

export function validateTeamRules(text: string): void {
	const lines = text.trim().split(/\r?\n/);
	if (lines.length > 40 || text.length > 8000)
		throw new Error('Team rules exceed their prompt budget.');
	let entries = 0;
	for (let i = 0; i < lines.length; i++) {
		if (!lines[i]?.startsWith('- ')) continue;
		entries++;
		if (!/^ {2}(source: #\d+ ".+"|earned: \d{4}-\d{2}-\d{2}, .+)$/.test(lines[i + 1] ?? ''))
			throw new Error('Each team rule needs its own source or earned correction.');
	}
	if (!entries) throw new Error('Team rules contain no sourced entries.');
}

export function teamRules(): string {
	let text: string;
	try {
		text = readFileSync(join(storageRoot(), 'team-rules.md'), 'utf8');
	} catch (error: unknown) {
		if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return '';
		throw error;
	}
	validateTeamRules(text);
	return text.trim();
}
