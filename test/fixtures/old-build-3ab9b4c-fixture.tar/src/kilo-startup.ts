import { randomUUID } from 'node:crypto';

import { captureKiloModel } from './kilo-model-observation.ts';
import { startKiloTurnStream } from './kilo-turn-stream.ts';
import { observeLaunch, providerUp } from './launch-phase.ts';

const prompt =
	'Follow your current Summon instructions. Run summon --checkpoint, read each delivered batch before passing its receipt, and respond to pending user requests within your authority.';

/** A separate authenticated worker prevents delivery to another Kilo session or shared daemon. */
export async function kiloStartup(
	cwd: string,
	sessionId: string,
	model?: string,
	launch?: { name: string; nonce: string },
) {
	const reservation = Bun.serve({ hostname: '127.0.0.1', port: 0, fetch: () => new Response() });
	const port = reservation.port;
	await reservation.stop(true);
	const password = randomUUID();
	const headers = {
		Authorization: `Basic ${Buffer.from(`kilo:${password}`).toString('base64')}`,
		'Content-Type': 'application/json',
	};
	const url = `http://127.0.0.1:${port}/session/${encodeURIComponent(sessionId)}`;
	const query = `?directory=${encodeURIComponent(cwd)}`;
	return {
		args: ['--hostname', '127.0.0.1', '--port', String(port)],
		env: {
			KILO_NO_DAEMON: '1',
			KILO_SERVER_USERNAME: 'kilo',
			KILO_SERVER_PASSWORD: password,
		},
		start: async (signal: AbortSignal): Promise<void> => {
			const readySignal = AbortSignal.any([signal, AbortSignal.timeout(30000)]);
			let ready = false;
			while (!ready) {
				readySignal.throwIfAborted();
				try {
					const response = await fetch(`${url}${query}`, {
						headers,
						redirect: 'error',
						signal: AbortSignal.any([readySignal, AbortSignal.timeout(1000)]),
					});
					// The server is bound to an ephemeral credential, and the exact session must exist.
					ready = response.ok;
					await response.body?.cancel();
				} catch {
					readySignal.throwIfAborted();
				}
				if (!ready) await Bun.sleep(250);
			}
			signal.throwIfAborted();
			if (launch) {
				let capturing = false;
				let requested = false;
				const modelChanged = (): void => {
					requested = true;
					if (capturing) return;
					capturing = true;
					void (async () => {
						try {
							while (requested && !signal.aborted) {
								requested = false;
								await captureKiloModel(
									`http://127.0.0.1:${port}`,
									query,
									headers,
									signal,
									launch,
									sessionId,
								).catch(() => {});
							}
						} finally {
							capturing = false;
						}
					})();
				};
				// Subscribe before startup input so its real busy/idle pair cannot be missed.
				const unavailable = (): void => {
					if (!signal.aborted)
						console.error(
							'Kilo completion unavailable; ordinary notices remain queued.',
						);
				};
				try {
					const { completion } = await startKiloTurnStream(
						`http://127.0.0.1:${port}/event${query}`,
						headers,
						signal,
						launch,
						sessionId,
						modelChanged,
					);
					void completion.catch(unavailable);
					modelChanged();
				} catch {
					unavailable();
					signal.throwIfAborted();
				}
			}
			if (launch)
				await observeLaunch(
					providerUp(launch.name, launch.nonce, 'kilo', 'kilo-owned-session'),
				);
			const slash = model?.indexOf('/') ?? -1;
			// Never retry a POST: timeout or disconnect can occur after Kilo accepted the turn.
			const response = await fetch(`${url}/prompt_async${query}`, {
				method: 'POST',
				headers,
				redirect: 'error',
				signal: AbortSignal.any([signal, AbortSignal.timeout(5000)]),
				body: JSON.stringify({
					...(model && slash > 0
						? {
								model: {
									providerID: model.slice(0, slash),
									modelID: model.slice(slash + 1),
								},
							}
						: {}),
					parts: [{ type: 'text', text: prompt }],
				}),
			});
			await response.body?.cancel();
			if (!response.ok) throw new Error('Kilo did not acknowledge its startup turn.');
		},
	};
}
