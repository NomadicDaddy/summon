import { join } from 'node:path';
import { z } from 'zod';

import { atomicWrite, locked, optionalText } from './mail-files.ts';
import { ownMailbox } from './mail-identity.ts';
import { runtimePath } from './mail-session.ts';

const schema = z
	.object({
		version: z.literal(1),
		nonce: z.string().regex(/^[a-z0-9-]+$/i),
		thread: z.string().min(1).max(128),
		observer: z.string().min(1).max(128).nullable(),
		phase: z.enum(['unknown', 'busy', 'idle']),
		busyObserved: z.boolean(),
		bootstrapUsed: z.boolean(),
		generation: z.number().int().nonnegative(),
	})
	.strict();

function pathFor(name: string, nonce: string): string {
	ownMailbox(name);
	if (!/^[a-z0-9-]+$/i.test(nonce)) throw new Error('Invalid launch nonce.');
	return join(runtimePath(name), `${nonce}.kilo-turn`);
}

export async function kiloTurn(name: string, nonce: string) {
	const raw = await optionalText(pathFor(name, nonce));
	if (raw === undefined) return undefined;
	try {
		const state = schema.parse(JSON.parse(raw) as unknown);
		if (state.nonce === nonce) return state;
	} catch {
		/* Persist only scoped observation metadata; never echo provider event payloads. */
	}
	throw new Error('Invalid Kilo turn observation; notices remain queued.');
}

/** Receiver attachment preserves observations; a new stream cannot inherit old idle. */
export async function initializeKiloTurn(
	name: string,
	nonce: string,
	thread: string,
	observer?: string,
): Promise<void> {
	const path = pathFor(name, nonce);
	await locked(`${path}.lock`, async () => {
		const current = await kiloTurn(name, nonce);
		if (current && current.thread !== thread)
			throw new Error('Kilo turn belongs to another thread.');
		if (current && observer === undefined) return;
		await atomicWrite(
			path,
			JSON.stringify(
				schema.parse({
					version: 1,
					nonce,
					thread,
					observer: observer ?? null,
					phase: 'unknown',
					busyObserved: false,
					bootstrapUsed: current?.bootstrapUsed ?? false,
					generation: (current?.generation ?? 0) + 1,
				}),
			),
		);
	});
}

export async function kiloNoticeAllowed(name: string, nonce: string): Promise<boolean> {
	const state = await kiloTurn(name, nonce);
	const ready = await optionalText(join(runtimePath(name), `${nonce}.ready`));
	return !!state && (state.phase === 'idle' || (!state.bootstrapUsed && ready !== nonce));
}

/** Reserve before writing. A repeated idle event cannot release this reservation. */
export async function reserveKiloNotice(name: string, nonce: string): Promise<() => Promise<void>> {
	const path = pathFor(name, nonce);
	return locked(`${path}.lock`, async () => {
		const state = await kiloTurn(name, nonce);
		if (!state || !(await kiloNoticeAllowed(name, nonce)))
			throw new Error('Kilo is awaiting verified turn completion.');
		await atomicWrite(
			path,
			JSON.stringify({
				...state,
				phase: 'busy',
				busyObserved: false,
				bootstrapUsed: true,
				generation: state.generation + 1,
			}),
		);
		return async () => {
			await locked(`${path}.lock`, async () => {
				const current = await kiloTurn(name, nonce);
				if (current?.generation === state.generation + 1)
					await atomicWrite(path, JSON.stringify(state));
			});
		};
	});
}

export async function kiloInputSubmitted(name: string, nonce: string): Promise<void> {
	const path = pathFor(name, nonce);
	await locked(`${path}.lock`, async () => {
		const state = await kiloTurn(name, nonce);
		if (state)
			await atomicWrite(
				path,
				JSON.stringify({
					...state,
					phase: 'busy',
					busyObserved: false,
					generation: state.generation + 1,
				}),
			);
	});
}

export async function invalidateKiloTurn(
	name: string,
	nonce: string,
	observer: string,
): Promise<void> {
	const path = pathFor(name, nonce);
	await locked(`${path}.lock`, async () => {
		const state = await kiloTurn(name, nonce);
		if (state?.observer === observer)
			await atomicWrite(
				path,
				JSON.stringify({
					...state,
					phase: 'unknown',
					busyObserved: false,
					generation: state.generation + 1,
				}),
			);
	});
}

/** The ordered, authenticated owned-server stream is authoritative, never a sidebar status. */
export async function observeKiloTurn(
	name: string,
	nonce: string,
	observer: string,
	input: unknown,
): Promise<void> {
	if (!input || typeof input !== 'object' || Array.isArray(input)) return;
	const event = input as Record<string, unknown>;
	if (
		!event.properties ||
		typeof event.properties !== 'object' ||
		Array.isArray(event.properties)
	)
		return;
	const properties = event.properties as Record<string, unknown>;
	if (event.type !== 'session.status') return;
	const status =
		properties.status && typeof properties.status === 'object'
			? (properties.status as Record<string, unknown>).type
			: undefined;
	const path = pathFor(name, nonce);
	await locked(`${path}.lock`, async () => {
		const state = await kiloTurn(name, nonce);
		if (!state || state.observer !== observer || state.thread !== properties.sessionID) return;
		// Native busy must be observed after reservation: duplicate completion cannot queue two turns.
		if (status === 'idle' && !state.busyObserved) return;
		await atomicWrite(
			path,
			JSON.stringify({
				...state,
				phase:
					status === 'idle'
						? 'idle'
						: ['busy', 'retry'].includes(String(status))
							? 'busy'
							: 'unknown',
				busyObserved: status === 'busy' || status === 'retry',
				generation: state.generation + 1,
			}),
		);
	});
}
