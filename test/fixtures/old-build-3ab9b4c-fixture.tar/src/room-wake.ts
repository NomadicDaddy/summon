import { addressableText } from './room-address.ts';

interface WakeEvent {
	sender: { kind: string; id: string };
	text: string;
	replyTo: number | null;
}

export function mentionedSlugs(text: string, slugs: readonly string[]): string[] {
	if (/(?<![\p{L}\p{N}_@])@all(?![\p{L}\p{N}_])/iu.test(text)) return [...slugs];
	return slugs.filter((slug) => {
		const escaped = slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
		return new RegExp(`(?<![\\p{L}\\p{N}_@])@${escaped}(?![\\p{L}\\p{N}_-])`, 'iu').test(text);
	});
}

export function directlyAddressed(text: string, name: string): boolean {
	return mentionedSlugs(addressableText(text), [name]).length > 0;
}

/**
 * A burst is delivered once it has stopped, not once per message in it.
 *
 * The window is a DEBOUNCE measured from the last message, which is not what it used to be: it was
 * a throttle measured from the FIRST unread one, so it fired in the middle of a burst and then
 * again for the tail. Worse, addressed and human traffic bypassed it outright, so an active room
 * with the operator in it produced one notice per turn step. Since every notice carries the same
 * text - go and checkpoint - N of them tell a session exactly what one does, and the one that
 * arrives after the room settles is the one worth interrupting for.
 */
export const ROOM_WAKE_QUIET_MS = 30_000;
/**
 * A room that never falls quiet would starve a pure debounce, so the wake goes out regardless.
 *
 * This ceiling wants to sit well above the quiet window, or it stops being a starvation guard and
 * starts being the ordinary delivery path. Both were 30_000. Replaying a real 13-message room
 * burst against these functions, that produced 21 deliveries of which 7 fired on the ceiling
 * mid-burst - precisely the "fires in the middle of a burst and then again for the tail" behaviour
 * the debounce above was introduced to end. At 120_000 the same burst delivers 17 times, every one
 * of them decided by quiet, and the ceiling returns to covering only a room that genuinely will
 * not stop.
 *
 * It was NOT dead at 30_000 - quiet still decided 14 of the 21 - because a delivery clears the
 * batch and restarts `firstAt`, so the ceiling only wins inside a sustained run. Raising it
 * removes that remaining case rather than switching the debounce on.
 */
export const ROOM_WAKE_MAX_HOLD_MS = 120_000;

export interface RoomWakeBatch {
	firstAt: number;
	lastChangeAt: number;
	through: number;
}

/**
 * Records this tick's watermark and restarts the quiet window whenever it moved. The watermark is
 * what a poller can actually observe, so the debounce needs no per-event arrival times.
 */
export function trackRoomWakeBatch(
	batches: Map<string, RoomWakeBatch>,
	path: string,
	through: number,
	now = Date.now(),
): RoomWakeBatch {
	const existing = batches.get(path);
	if (!existing) {
		const started = { firstAt: now, lastChangeAt: now, through };
		batches.set(path, started);
		return started;
	}
	if (existing.through !== through) {
		existing.lastChangeAt = now;
		existing.through = through;
	}
	return existing;
}

export interface RoomWakeWindows {
	quiet: number;
	maxHold: number;
}

function envMs(name: string, fallback: number): number {
	const raw = process.env[name];
	if (raw === undefined) return fallback;
	const value = Number(raw);
	return Number.isFinite(value) && value >= 0 ? value : fallback;
}

/**
 * The suite collapses the quiet window to zero so a delivery test does not spend thirty seconds
 * waiting one out. The timing itself is covered by cases that pass their windows explicitly, which
 * is the only place it can be asserted without making the clock part of the test.
 */
export function roomWakeWindows(): RoomWakeWindows {
	return {
		quiet: envMs('SUMMON_ROOM_WAKE_QUIET_MS', ROOM_WAKE_QUIET_MS),
		maxHold: envMs('SUMMON_ROOM_WAKE_MAX_HOLD_MS', ROOM_WAKE_MAX_HOLD_MS),
	};
}

export function roomWakeDue(
	batch: RoomWakeBatch,
	now = Date.now(),
	windows = roomWakeWindows(),
): boolean {
	return now - batch.lastChangeAt >= windows.quiet || now - batch.firstAt >= windows.maxHold;
}

/**
 * Whether newly arrived traffic justifies re-notifying a session that was already told and has not
 * acknowledged yet. This no longer skips the delay - nothing does - it only decides whether a stale
 * wake is refreshed rather than left sitting behind an older unacknowledged cursor.
 */
export function roomWakeImmediate(name: string, events: WakeEvent[], ownIds: Set<number>): boolean {
	return events.some(
		(event) =>
			event.sender.kind === 'user' ||
			event.sender.kind === 'cli' ||
			(event.replyTo !== null && ownIds.has(event.replyTo)) ||
			directlyAddressed(event.text, name),
	);
}
