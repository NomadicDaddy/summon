import { checkpointText } from './checkpoint-text.ts';
import { checkpoint, checkpointManifest } from './checkpoint.ts';

export async function checkpointCommand(args: string[]): Promise<void> {
	let text = false;
	if (args.at(-2) === '--format' && args.at(-1) === 'text') {
		text = true;
		args = args.slice(0, -2);
	}
	if (args.length > (args[0] === 'manifest' ? 2 : 1) || args.includes('--format'))
		throw new Error(
			'Usage: summon --checkpoint [receipt] [--format text] | manifest [cursor] [--format text]',
		);
	const result =
		args[0] === 'manifest' ? await checkpointManifest(args[1]) : await checkpoint(args[0]);
	console.log(text ? checkpointText(result) : JSON.stringify(result));
}
