/**
 * Which key presses count as the operator typing at a teammate (Phillip #7266).
 *
 * The window sees every keyDown through before-input-event, including the Alt and Tab of an
 * Alt+Tab or the Windows key that switches to another window. Counting those renewed the
 * automatic hold on the window being LEFT, so the countdown started on an OS window switch. A
 * press is typing only when it could put something in front of the selected teammate: not a
 * modifier on its own, and not a chord the system owns.
 */
const MODIFIER_KEYS = new Set([
	'Alt',
	'AltGraph',
	'CapsLock',
	'Control',
	'Fn',
	'FnLock',
	'Hyper',
	'Meta',
	'NumLock',
	'ScrollLock',
	'Shift',
	'Super',
	'Symbol',
]);

export interface KeyPress {
	key: string;
	alt?: boolean;
	meta?: boolean;
}

export function typingKey(press: KeyPress): boolean {
	if (MODIFIER_KEYS.has(press.key)) return false;
	// The Windows key owns its chords; Alt+Tab and Alt+Escape switch windows.
	if (press.meta) return false;
	if (press.alt && (press.key === 'Tab' || press.key === 'Escape')) return false;
	return true;
}
