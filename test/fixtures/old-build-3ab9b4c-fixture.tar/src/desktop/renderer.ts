import { FitAddon } from '@xterm/addon-fit';
import { Terminal } from '@xterm/xterm';

import type { BoardMove, TeamSnapshot } from './types.ts';

import { setupBoardToggle } from './board-panel.ts';
import { setupDiary } from './diary-panel.ts';
import { setupErrorBanner } from './error-banner.ts';
import { setupHeadDownControls } from './head-down-controls.ts';
import { focusedHeadDown, headDownRosterRow, restoreHeadDownFocus } from './head-down-roster.ts';
import { canPauseNotifications, isHeadsDown } from './head-down-row.ts';
import { setupHibernationControls } from './hibernation-controls.ts';
import { readableError } from './ipc-error.ts';
import { setupMacroBar } from './macro-bar.ts';
import { setupMacros } from './macros.ts';
import { setupMaintenance } from './maintenance.ts';
import { memberDetail } from './member-detail.ts';
import { headerState, memberRow, memberWorkingText, writeStateLabel } from './member-identity.ts';
import { setupNotepad } from './notepad.ts';
import { setupNotificationPause } from './notification-pause-control.ts';
import { renderWelcome } from './onboarding.ts';
import { setupOperator } from './operator-pane.ts';
import { setupProviderFilters } from './provider-filters.ts';
import { setupRepos } from './repos-panel.ts';
import { restoreRestFocus, restRosterRow } from './rest-roster.ts';
import { setupRoom } from './room.ts';
import { setupRosterCoverage } from './roster-coverage.ts';
import { setupRosterProgress } from './roster-progress.ts';
import { memberSelection, selectionTarget } from './selection-focus.ts';
import { setupShortcuts } from './shortcuts.ts';
import { setupSplitters } from './splitters.ts';
import { faultStore, markFaultedRow, noteFault } from './teammate-faults.ts';
import { bindTerminalInput } from './terminal-input-origin.ts';
import { createThemedTerminal } from './terminal-style.ts';

function element(id: string): HTMLElement {
	const value = document.getElementById(id);
	if (!value) throw new Error(`Missing element ${id}`);
	return value;
}
const roster = element('roster');
const updateProviderFilters = setupProviderFilters(roster);
const terminalArea = element('terminals');
const empty = element('empty');
const start = element('start');
const stop = element('stop');
const errorBanner = setupErrorBanner(element);
const showError = errorBanner.show;
const updateHibernation = setupHibernationControls(errorBanner.from('hibernate'));
let addedSlug = '';
const updateHeadDown = setupHeadDownControls(errorBanner.from('head-down'));
const updatePause = setupNotificationPause(errorBanner.from('notification-pause'));
const maintenance = setupMaintenance((slug) => {
	addedSlug = slug;
});
element('roster-add').addEventListener('click', () => maintenance.add());
const updateRoom = setupRoom();
const updateCoverage = setupRosterCoverage();
const updateProgress = setupRosterProgress();
setupSplitters();
async function boardMove(id: string, revision: number, move: BoardMove): Promise<void> {
	await action(async () => {
		try {
			await window.team.boardMove(id, revision, move);
		} finally {
			// A notification error can follow a saved move; show the persisted lane in either case.
			updateBoard();
		}
	});
}
const updateBoard = setupBoardToggle(
	() =>
		window.team.boardRead().catch((error: unknown) => {
			showError(error, 'board.read');
			return null;
		}),
	() => snapshot.selected || null,
	{
		approve: (id, revision) => boardMove(id, revision, 'approve'),
		archive: (id, revision) => boardMove(id, revision, 'archive'),
		returnToBacklog: (id, revision) => boardMove(id, revision, 'backlog'),
		unblock: (id, revision) => boardMove(id, revision, 'unblock'),
	},
);
let snapshot: TeamSnapshot = { agents: [], selected: '' };
setupDiary(errorBanner.from('diary.read'));
setupNotepad();
setupShortcuts();
const panes = new Map<string, { terminal: Terminal; fit: FitAddon; node: HTMLDivElement }>();
const selectMember = memberSelection(
	(slug) => action(() => window.team.select(slug)),
	() => selectionTarget(snapshot, panes.get(snapshot.selected)?.terminal),
);
setupRepos(errorBanner.from('repos'), selectMember);
async function action(work: () => Promise<void>): Promise<boolean> {
	errorBanner.clear();
	try {
		await work();
		return true;
	} catch (error: unknown) {
		showError(error, 'window.action');
		return false;
	}
}
function pane(slug: string) {
	const existing = panes.get(slug);
	if (existing) return existing;
	const node = document.createElement('div');
	node.className = 'terminal-pane';
	node.hidden = snapshot.selected !== slug;
	terminalArea.append(node);
	const terminal = createThemedTerminal({
		...(snapshot.windowsPty ? { windowsPty: snapshot.windowsPty } : {}),
		scrollback: 2000,
	});
	const fit = new FitAddon();
	terminal.loadAddon(fit);
	terminal.open(node);
	bindTerminalInput(terminal, (data, humanInput) => window.team.input(slug, data, humanInput));
	terminal.onResize(({ cols, rows }) => window.team.resize(slug, cols, rows));
	const value = { terminal, fit, node };
	panes.set(slug, value);
	return value;
}
function fitSelected(): void {
	const current = panes.get(snapshot.selected);
	if (current && !current.node.hidden) {
		current.fit.fit();
		window.team.resize(snapshot.selected, current.terminal.cols, current.terminal.rows);
	}
}
const faults = faultStore();
function render(value: TeamSnapshot): void {
	const focusedRest =
		document.activeElement instanceof HTMLElement
			? document.activeElement.dataset.restSlug
			: undefined;
	const focusedSlug =
		document.activeElement instanceof HTMLElement && roster.contains(document.activeElement)
			? document.activeElement.dataset.slug
			: undefined;
	const focusedDecision = focusedHeadDown(roster);
	snapshot = value;
	faults.sync(new Map(value.agents.map((agent) => [agent.slug, agent.status])));
	const teamName = element('team-name');
	teamName.textContent = value.team ?? '';
	teamName.hidden = !value.team;
	element('team-started').textContent = value.startedAt
		? `Started ${new Date(value.startedAt).toLocaleString(undefined, { timeZoneName: 'short' })}`
		: '';
	element('team-started').title = value.startedAt ?? '';
	maintenance.update(value);
	const noTeammates = value.agents.length === 0;
	element('roster-add').textContent = noTeammates ? 'Add your first teammate' : 'Add teammate';
	element('provider-filters').hidden = noTeammates;
	element('presence-filters').hidden = noTeammates;
	updateRoom(value);
	roster.replaceChildren();
	for (const agent of value.agents) {
		const button = memberRow(agent, value.selected);
		markFaultedRow(button, agent.slug, faults, errorBanner.display, () =>
			selectMember(agent.slug),
		);
		roster.append(
			headDownRosterRow(
				agent,
				restRosterRow(agent, button, (slug, confirmation) => {
					void action(() => window.team.stopRest(slug, confirmation));
				}),
				(slug, id, approve) => {
					void action(() => window.team.headDownDecision(slug, id, approve));
				},
			),
		);
		if (agent.slug === focusedSlug) button.focus({ preventScroll: true });
		if (agent.status === 'running') pane(agent.slug);
	}
	updateProviderFilters();
	restoreRestFocus(roster, focusedRest);
	restoreHeadDownFocus(roster, focusedDecision);
	element('count').textContent =
		`${value.agents.filter((agent) => agent.status === 'running').length} here`;
	updateCoverage(value.agents);
	updateProgress(value.agents);
	const selected = value.agents.find((agent) => agent.slug === value.selected);
	updateHibernation(selected);
	updateHeadDown(selected);
	updatePause(value.notificationPause, canPauseNotifications(selected), isHeadsDown(selected));
	element('name-text').textContent = selected?.name ?? 'Your Team Window';
	element('name-role').hidden = selected?.memberType !== 'pm';
	const nameState = element('name-state');
	const activity =
		selected && (selected.status === 'running' || selected.status === 'elsewhere')
			? selected.activity
			: undefined;
	const header = headerState(selected, activity);
	nameState.className = header.className;
	nameState.hidden = !selected;
	const stateLabel = header.label;
	writeStateLabel(element('name-state-label'), selected, stateLabel);
	element('name-state-label').title = header.title;
	element('header-working').textContent = selected ? memberWorkingText(selected) : '';
	const detail = memberDetail(selected);
	element('detail').textContent = detail.text;
	element('detail').title = detail.title;
	element('status').textContent = stateLabel || 'Ready';
	start.hidden = !selected || ['running', 'elsewhere', 'hibernated'].includes(selected.status);
	start.textContent = ['exited', 'stopped'].includes(selected?.status ?? '')
		? 'Resume'
		: 'Summon';
	stop.hidden = !selected?.ownedSession;
	const running = selected?.status === 'running';
	const quickReplies = element('agent-quick-replies');
	quickReplies.hidden = !running;
	for (const button of quickReplies.querySelectorAll('button')) button.disabled = !running;
	for (const [slug, value] of panes) {
		value.node.hidden = slug !== snapshot.selected;
		value.terminal.options.disableStdin =
			snapshot.agents.find((agent) => agent.slug === slug)?.status === 'hibernated';
	}
	empty.hidden = !!selected && panes.has(selected.slug);
	renderWelcome(element, selected, addedSlug, noTeammates);
	updateBoard();
	requestAnimationFrame(fitSelected);
}
for (const control of [start, element('empty-start')])
	control.addEventListener('click', () => {
		if (snapshot.agents.length === 0) {
			maintenance.add();
			return;
		}
		const selected = snapshot.agents.find((agent) => agent.slug === snapshot.selected);
		if (!selected) return;
		void action(async () => {
			try {
				await window.team.start(selected.slug);
			} catch (cause: unknown) {
				const message = readableError(cause);
				throw new Error(`${selected.name} could not start. ${message.split('\n')[0]}`, {
					cause,
				});
			}
		});
	});
stop.addEventListener('click', () => {
	const selected = snapshot.agents.find((agent) => agent.slug === snapshot.selected);
	if (!selected) return;
	if (
		(selected.activity === 'busy' || selected.activity === 'needs-user') &&
		!window.confirm(`Stop ${selected.name}? Unsaved work in its session will be terminated.`)
	)
		return;
	void action(() => window.team.stop(selected.slug));
});
new ResizeObserver(fitSelected).observe(terminalArea);
window.team.onImagePaste(() => {
	const current = panes.get(snapshot.selected);
	if (current?.node.contains(document.activeElement))
		window.team.input(snapshot.selected, '\x16');
});
window.team.onEvent((event) => {
	if (event.type === 'snapshot') render(event.value);
	else if (event.type === 'reset') {
		const previous = panes.get(event.slug);
		previous?.terminal.dispose();
		previous?.node.remove();
		panes.delete(event.slug);
		pane(event.slug);
		requestAnimationFrame(fitSelected);
	} else if (event.type === 'output') pane(event.slug).terminal.write(event.data);
	else if (event.type === 'board') updateBoard();
	else noteFault(faults, event, errorBanner, () => render(snapshot));
});
void window.team
	.ready()
	.then((value) => {
		render(value);
		setupOperator(value.windowsPty);
	})
	.catch(errorBanner.from('window.ready'));
setupMacros();
element('build-info').addEventListener('click', (event) => {
	event.preventDefault();
	void window.team.openRepository().catch(errorBanner.from('window.open-repository'));
});
setupMacroBar(
	element('agent-quick-replies'),
	(text, send) => {
		if (snapshot.agents.find((agent) => agent.slug === snapshot.selected)?.status !== 'running')
			return;
		const current = pane(snapshot.selected);
		current.terminal.paste(text);
		if (send) window.team.input(snapshot.selected, '\r');
		current.terminal.focus();
	},
	() =>
		snapshot.agents.some(
			(agent) => agent.slug === snapshot.selected && agent.status === 'running',
		),
);
