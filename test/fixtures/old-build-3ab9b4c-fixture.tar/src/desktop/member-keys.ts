/**
 * Ctrl+1 to Ctrl+9 select a teammate by position in the sidebar (card 008508fe).
 *
 * The position is the one on screen: rows hidden by the provider or Online/Offline filter are
 * skipped, so the third key is always the third row you can see. Only the first nine have a key;
 * Phillip accepted no key for the tenth onward.
 *
 * Selecting is done by pressing the row, so this holds no copy of how selection works: a running
 * teammate's terminal takes focus exactly as it does on a click.
 */

/** The parts of a key press this shortcut reads. */
export interface MemberKeyPress {
	altKey: boolean;
	code: string;
	ctrlKey: boolean;
	metaKey: boolean;
	shiftKey: boolean;
}

/**
 * The sidebar position a key press asks for, counted from zero, or undefined when the press is
 * not this shortcut. Ctrl with a top-row digit and nothing else: Shift, Alt and the number pad
 * are left to whatever else wants them.
 */
export function memberKeyIndex(press: MemberKeyPress): number | undefined {
	if (!press.ctrlKey || press.altKey || press.shiftKey || press.metaKey) return undefined;
	const digit = /^Digit([1-9])$/.exec(press.code)?.[1];
	return digit === undefined ? undefined : Number(digit) - 1;
}

/** How many teammates have a key. */
export const MEMBER_KEYS = 9;

const visibleRows = (): HTMLElement[] =>
	[...document.querySelectorAll<HTMLElement>('#roster .member[data-slug]')].filter(
		(row) => row.closest('[hidden]') === null,
	);

/**
 * Takes the nine keys and keeps each visible row's key announced. Called once, with the rest of
 * the window's shortcuts.
 */
export function setupMemberKeys(): void {
	const roster = document.getElementById('roster');
	if (roster === null) return;
	// The roster rebuilds its rows on every update and the filters hide rows in place, so the
	// announced key is rewritten whenever either happens. It is an attribute only: nothing drawn.
	const label = (): void => {
		const rows = visibleRows();
		for (const row of roster.querySelectorAll<HTMLElement>('.member[data-slug]')) {
			const position = rows.indexOf(row);
			const wanted =
				position >= 0 && position < MEMBER_KEYS ? `Control+${String(position + 1)}` : null;
			if (row.getAttribute('aria-keyshortcuts') === wanted) continue;
			if (wanted === null) row.removeAttribute('aria-keyshortcuts');
			else row.setAttribute('aria-keyshortcuts', wanted);
		}
	};
	new MutationObserver(label).observe(roster, {
		attributeFilter: ['hidden'],
		attributes: true,
		childList: true,
		subtree: true,
	});
	label();
	// Counts key presses that selected somebody, so an older press can tell it has been overtaken.
	let request = 0;
	document.addEventListener(
		'keydown',
		(event) => {
			const index = memberKeyIndex(event);
			if (index === undefined) return;
			// Taken before a terminal sees it, and taken even when nobody is at that position or a
			// dialog is open: a key that is the window's sometimes and the CLI's at other times
			// would send a stray control character whenever the roster was short.
			event.preventDefault();
			event.stopImmediatePropagation();
			if (event.repeat || document.querySelector('dialog[open]') !== null) return;
			const row = visibleRows()[index];
			if (row === undefined) return;
			const slug = row.dataset['slug'];
			row.click();
			// A click with the mouse leaves focus on the row, or in the teammate's terminal when one
			// is running. Pressed from here focus could be left nowhere, or on the row of the
			// teammate just left, so once the selection has landed the new row is given it. Focus
			// anywhere else is not touched: a message being typed stays where it is, and a terminal
			// the selection has already focused keeps it.
			//
			// Two guards, the same two selection-focus.ts has (Roger #8619). A later key press
			// supersedes this one: without that, Ctrl+1 then Ctrl+2 could end with focus on row 1.
			// And focus is given only to the row that is selected: a selection that failed or never
			// landed leaves focus alone rather than pointing at a teammate who is not selected.
			const mine = ++request;
			const settle = (tries: number): void => {
				if (mine !== request) return;
				const current = visibleRows().find(
					(candidate) => candidate.dataset['slug'] === slug,
				);
				if (current?.getAttribute('aria-current') !== 'true') {
					if (tries > 0) {
						setTimeout(() => {
							settle(tries - 1);
						}, 50);
					}
					return;
				}
				const active = document.activeElement;
				if (active === document.body || active?.closest('#roster') === roster)
					current.focus();
			};
			settle(40);
		},
		true,
	);
}
