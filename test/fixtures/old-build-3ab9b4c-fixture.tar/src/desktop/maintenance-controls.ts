/**
 * The self-contained controls that were sitting inside the maintenance dialog's one closure.
 *
 * Neither belongs to the profile form they were nested in: a view preference for the sidebar, a usage
 * reading, the removal, the team switches. They were there because the closure was where
 * everything went - setupMaintenance had become a single 300-line function, which is the audit
 * finding this resolves, and the last several commits to that file each made it longer.
 */

import { applyColorTheme, readColorTheme, saveColorTheme } from './color-theme.ts';
import { reportFault } from './fault-report.ts';
import { rethemeTerminals } from './terminal-style.ts';

/** The profile form's fields, by the suffix of their `maint-` element id. */
export const profileFields = [
	'name',
	'provider',
	'cwd',
	'expertise',
	'domain',
	'backup',
	'notes',
	'sessionId',
	'model',
	'lmStudioUrl',
	'claudeConfigDir',
] as const;

/**
 * The window's own preferences: whether the roster shows each teammate's domain coverage, and the
 * colour theme (card cca8d66e).
 *
 * Window preferences rather than team data, so they live in localStorage and survive nothing but
 * this browser profile. Every read and write is guarded: storage throws in some contexts, and a
 * preference is worth less than the dialog it would take down.
 */
export function setupWindowPreferences(get: (id: string) => HTMLElement, error: HTMLElement): void {
	const lightTheme = get('maint-light-theme') as HTMLInputElement;
	lightTheme.checked = readColorTheme() === 'light';
	lightTheme.addEventListener('change', () => {
		const theme = lightTheme.checked ? 'light' : 'dark';
		applyColorTheme(theme);
		rethemeTerminals();
		if (!saveColorTheme(theme)) {
			error.textContent = 'The theme changed for this window but could not be saved.';
			reportFault({ level: 'error', source: 'maintenance.theme', text: error.textContent });
		}
	});
	const showCoverage = get('maint-show-coverage') as HTMLInputElement;
	const coverage = get('roster-coverage');
	try {
		showCoverage.checked = localStorage.getItem('summon.showDomainCoverage') !== 'false';
	} catch {
		// Keep the default visible when local preferences cannot be read.
	}
	coverage.hidden = !showCoverage.checked;
	showCoverage.addEventListener('change', () => {
		coverage.hidden = !showCoverage.checked;
		try {
			localStorage.setItem('summon.showDomainCoverage', String(showCoverage.checked));
		} catch {
			error.textContent =
				'Coverage visibility changed for this window but could not be saved.';
			reportFault({
				level: 'error',
				source: 'maintenance.coverage',
				text: error.textContent,
			});
		}
	});
}

/**
 * Reading a teammate's provider usage.
 *
 * Its own control rather than part of the form: nothing here edits a profile, and the reading is
 * about the account behind the teammate rather than the record in front of you.
 */
export function setupUsageReport(
	get: (id: string) => HTMLElement,
	run: (work: () => Promise<void>) => void,
	current: () => null | string,
): void {
	get('maint-usage-refresh').addEventListener('click', () => {
		run(async () => {
			const existing = current();
			if (!existing) throw new Error('Choose a registered teammate first.');
			get('maint-usage').textContent = 'Reading provider usage…';
			const report = await window.team.usage(existing);
			get('maint-usage').textContent =
				`${report.lines.join('\n')}\nChecked ${new Date(report.checkedAt).toLocaleString()}`;
		});
	});
}

/**
 * Removing a teammate, behind the typed confirmation.
 *
 * The caller is told what happened and decides what its own state becomes - this owns the rule for
 * whether a removal may proceed and nothing about what the dialog looks like afterwards. The
 * confirmation compares against the slug rather than the display name because the slug is what the
 * removal acts on, and a near-miss here deletes the wrong teammate's files.
 */
export function setupRemoval(
	get: (id: string) => HTMLElement,
	run: (work: () => Promise<void>) => void,
	current: () => null | string,
	removed: (archive: boolean) => Promise<void>,
): void {
	get('maint-remove').addEventListener('click', () => {
		run(async () => {
			const existing = current();
			if (!existing) return;
			if ((get('maint-confirm') as HTMLInputElement).value.trim().toLowerCase() !== existing)
				throw new Error(`Type ${existing} to confirm removal.`);
			const archive = (get('maint-mode') as HTMLSelectElement).value === 'archive';
			await window.team.removeProfile(existing, archive);
			await removed(archive);
		});
	});
}

/**
 * The two team-wide switches: whether mentions wake a stopped teammate, and whether Claude stops to
 * confirm its development channel at every start.
 *
 * They live here for the reason this file exists at all - setupMaintenance was already at its line
 * limit when the second one arrived, and the comment at the top of this module records that the
 * previous several commits to that file each made it longer. Grouping them also fixes something
 * real rather than only moving lines: both now load from ONE read of the settings object, where
 * before each read it separately, which is exactly how a dialog ends up showing one of two settings
 * stale.
 *
 * Checked means live, and neither mode name reaches the interface. The operator is deciding whether
 * Claude prompts; `live` and `checkpoint` are what the setting is called underneath.
 */
export function setupTeamSettings(
	get: (id: string) => HTMLElement,
	run: (work: () => Promise<void>) => void,
): { apply: () => Promise<void>; setBusy: (busy: boolean) => void } {
	const wakeMentions = get('maint-wake-mentions') as HTMLInputElement;
	const claudeLive = get('maint-claude-live') as HTMLInputElement;
	const autoHold = get('maint-auto-hold') as HTMLInputElement;
	const holdSeconds = get('maint-hold-seconds') as HTMLInputElement;
	// A refused save puts the box back, so the dialog never shows a state the file does not hold.
	const bind = (box: HTMLInputElement, change: (checked: boolean) => Promise<unknown>): void => {
		box.addEventListener('change', () => {
			const requested = box.checked;
			run(async () => {
				try {
					await change(requested);
				} catch (error: unknown) {
					box.checked = !requested;
					throw error;
				}
			});
		});
	};
	bind(wakeMentions, (wakeOnMention) => window.team.saveSettings({ wakeOnMention }));
	bind(claudeLive, (live) =>
		window.team.saveSettings({ claudeDelivery: live ? 'live' : 'checkpoint' }),
	);
	bind(autoHold, (hold) => window.team.saveSettings({ autoHold: hold }));
	// The seconds field saves on change; a refused value (blank, fraction, out of range) goes
	// back to the saved one, so the dialog never shows a countdown the file does not hold.
	let savedSeconds = holdSeconds.value;
	holdSeconds.addEventListener('change', () => {
		const requested = holdSeconds.value.trim();
		run(async () => {
			try {
				const settings = await window.team.saveSettings({ holdSeconds: Number(requested) });
				savedSeconds = String(settings.holdSeconds);
				holdSeconds.value = savedSeconds;
			} catch (error: unknown) {
				holdSeconds.value = savedSeconds;
				throw error;
			}
		});
	});
	return {
		apply: async (): Promise<void> => {
			const settings = await window.team.settings();
			wakeMentions.checked = settings.wakeOnMention;
			claudeLive.checked = settings.claudeDelivery === 'live';
			autoHold.checked = settings.autoHold;
			savedSeconds = String(settings.holdSeconds);
			holdSeconds.value = savedSeconds;
		},
		setBusy: (busy: boolean): void => {
			wakeMentions.disabled = busy;
			claudeLive.disabled = busy;
			autoHold.disabled = busy;
			holdSeconds.disabled = busy;
		},
	};
}
