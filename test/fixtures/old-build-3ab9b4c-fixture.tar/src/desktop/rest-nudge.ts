import { join } from 'node:path';

import type { Team } from './team.ts';

import { readActivity } from '../agent-activity.ts';
import { assertAutomaticNoticeAllowed, automaticNoticeSuppressed } from '../automatic-notice.ts';
import { atomicWrite, locked, optionalText } from '../mail-files.ts';
import { runtimePath } from '../mail-session.ts';
import { sendMessage } from '../mailbox.ts';
import { assertTerminalDraftClear } from './terminal-draft.ts';

/** One question per idle episode, never a derived confirmation or a stop. */
export async function nudgeRest(team: Team, name: string, now = Date.now()): Promise<void> {
	if (await automaticNoticeSuppressed(name)) return;
	const session = team.sessions.get(name);
	if (session?.agent.status !== 'running') return;
	const activity = await readActivity(name);
	if (
		activity?.state !== 'idle' ||
		!Number.isFinite(Date.parse(activity.updatedAt)) ||
		now - Date.parse(activity.updatedAt) < 10 * 60000
	)
		return;
	// This asks the agent to reconcile its work. Requiring rest eligibility here would
	// suppress the question precisely when stale cards or unread mail need that review.
	// The separate --rest ready command still enforces every eligibility check.
	const path = join(runtimePath(name), 'rest-nudge');
	await locked(`${path}.lock`, async () => {
		const episode = `${activity.nonce}:${activity.updatedAt}`;
		if ((await optionalText(path)) === episode) return;
		const message =
			'You have been idle for a while. Please check your cards, mail and scheduled duties. Update any unrecorded work. If nothing is actionable and you are ready for the operator to stop your session, explicitly confirm with summon --rest ready. Stay busy if you have unfinished work; this question does not stop you.';
		await assertAutomaticNoticeAllowed(name);
		if (session.agent.provider === 'kilo') assertTerminalDraftClear(session.pty);
		await sendMessage(name, name, message, {
			system: { purpose: 'rest-nudge', nonce: activity.nonce, idleSince: activity.updatedAt },
		});
		await atomicWrite(path, episode);
	});
}
