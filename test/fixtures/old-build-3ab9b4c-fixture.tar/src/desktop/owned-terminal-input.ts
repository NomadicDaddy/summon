import type { TerminalProcess } from './team.ts';
import type { TeamAgent } from './types.ts';

import { readActivity } from '../agent-activity.ts';
import { claudeInputSubmitted } from '../claude-turn-state.ts';
import { grokInputSubmitted } from '../grok-turn-state.ts';
import { isHibernated } from '../hibernation.ts';
import { kiloInputSubmitted } from '../kilo-turn-state.ts';
import { recordClaudeInput } from './claude-terminal-input.ts';
import { MAX_TERMINAL_INPUT, validTerminalSize } from './pty-process.ts';
import { recordTerminalDraft, saveTerminalDraft, terminalDraft } from './terminal-draft.ts';

/** Preserve the existing provider draft gates while Team keeps lifecycle recording bounded. */
export async function inputToOwnedTerminal(
	slug: string,
	data: string,
	humanInput: boolean,
	currentSession: () =>
		| {
				agent: TeamAgent;
				pty: TerminalProcess;
				terminalNotices: boolean;
				stopRequested?: boolean;
		  }
		| undefined,
): Promise<void> {
	if (data.length > MAX_TERMINAL_INPUT) throw new Error('Terminal input is too large.');
	if (await isHibernated(slug)) throw new Error(`${slug} is hibernated; use Unhibernate first.`);
	const session = currentSession();
	if (session?.agent.status !== 'running' || session.stopRequested) return;
	if (
		humanInput &&
		['claude', 'grok', 'kilo'].includes(session.agent.provider) &&
		(session.agent.provider !== 'claude' || session.terminalNotices) &&
		/^(?:\r|\n|\r\n)$/.test(data)
	) {
		// PTY notices must not race human Enter. Claude's native channel never types into the
		// composer; its authenticated native hooks, rather than an ignored empty Enter, own busy.
		const submissionVersion = terminalDraft(session.pty).version + 1;
		saveTerminalDraft(session.pty, submissionVersion, true);
		const activity = await readActivity(slug);
		const current = currentSession();
		if (current !== session || current.agent.status !== 'running' || current.stopRequested)
			return;
		if (activity) {
			if (session.agent.provider === 'grok') await grokInputSubmitted(slug, activity.nonce);
			else if (session.agent.provider === 'claude')
				await claudeInputSubmitted(slug, activity.nonce);
			else await kiloInputSubmitted(slug, activity.nonce);
		}
		const latest = currentSession();
		if (latest !== session || latest.stopRequested) return;
		session.pty.write(data);
		// Concurrent typing owns a newer draft and must survive this older submission.
		if (terminalDraft(session.pty).version === submissionVersion)
			saveTerminalDraft(session.pty, submissionVersion + 1, false);
		return;
	}
	if (session.agent.provider === 'claude') recordClaudeInput(session.pty, data, humanInput);
	else recordTerminalDraft(session.pty, data, humanInput, session.agent.provider === 'grok');
	session.pty.write(data);
}

export function resizeOwnedTerminal(
	slug: string,
	cols: number,
	rows: number,
	dimensions: Map<string, { cols: number; rows: number }>,
	sessions: ReadonlyMap<string, { agent: TeamAgent; pty: TerminalProcess }>,
): void {
	if (!validTerminalSize(cols, rows)) return;
	const previous = dimensions.get(slug);
	if (previous?.cols === cols && previous.rows === rows) return;
	dimensions.set(slug, { cols, rows });
	const session = sessions.get(slug);
	if (session?.agent.status === 'running') session.pty.resize(cols, rows);
}
