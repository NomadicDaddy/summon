import type { NotificationPauseView } from './notification-pause.ts';
import type { TeamSnapshot } from './types.ts';

import { publishLaunchStatus } from '../launch-status.ts';
import { teamLabel } from '../store.ts';
import { teamSnapshot } from './team-snapshot.ts';

/** The window publishes its observed roster and verifies coverage against its own live children. */
export async function publicTeamSnapshot(
	context: Parameters<typeof teamSnapshot>[0],
	notificationPause?: NotificationPauseView,
): Promise<TeamSnapshot> {
	const sampledAt = Date.now();
	const team = teamLabel();
	const value = {
		...(notificationPause ? { notificationPause } : {}),
		...(await teamSnapshot(context)),
		...(team ? { team } : {}),
	};
	await publishLaunchStatus(
		value,
		sampledAt,
		context.reported,
		(message) => context.emit({ type: 'error', message, source: 'launch-status' }),
		[...context.sessions]
			.filter(([, session]) => session.agent.status === 'running')
			.map(([slug]) => slug),
	);
	return value;
}
