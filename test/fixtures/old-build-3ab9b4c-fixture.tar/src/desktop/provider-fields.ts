/** Account selection clears the previous account's conversation ID before saving. */
export function setupProviderFields(
	get: (id: string) => HTMLElement,
	run: (work: () => Promise<void>) => void,
): {
	update: () => void;
} {
	const directory = get('maint-claudeConfigDir') as HTMLInputElement;
	const provider = get('maint-provider') as HTMLSelectElement;
	const session = get('maint-sessionId') as HTMLInputElement;
	const row = get('maint-claude-account');
	const update = (): void => {
		const claude = provider.value === 'claude';
		row.hidden = !claude;
		directory.disabled = !claude;
		if (!claude) directory.value = '';
		const kilo = provider.value === 'kilo';
		for (const id of ['maint-model', 'maint-lmStudioUrl']) {
			const field = get(id) as HTMLInputElement;
			field.disabled = !kilo;
			if (!kilo) field.value = '';
		}
		for (const node of get('maint-form').querySelectorAll<HTMLElement>('[data-kilo-field]'))
			node.hidden = !kilo;
	};
	directory.addEventListener('input', () => {
		session.value = '';
	});
	get('maint-claude-browse').addEventListener('click', () => {
		run(async () => {
			const path = await window.team.chooseFolder();
			if (path === null) return;
			directory.value = path;
			session.value = '';
		});
	});
	provider.addEventListener('change', update);
	return { update };
}
