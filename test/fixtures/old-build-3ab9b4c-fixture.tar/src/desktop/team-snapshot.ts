import { release } from 'node:os';

import type { OwnedLaunch } from '../launch-phase-model.ts';
import type { TeamAgent, TeamEvent, TeamSnapshot } from './types.ts';

import { readActivity } from '../agent-activity.ts';
import { claudeConfigDirectory } from '../claude-config.ts';
import { claudeTurn } from '../claude-turn-state.ts';
import { canManageHeadDown } from '../head-down-access.ts';
import { headDownView } from '../head-down-model.ts';
import { observeGrokSession } from '../launch-phase.ts';
import { memberLabel } from '../member-role.ts';
import { refreshModelInfo } from '../provider-model-info.ts';
import { readRest } from '../rest.ts';
import { roomProgress } from '../room-progress.ts';
import { isAgentRunning } from '../session-lock.ts';
import { listAgentSlugs, loadAgent } from '../store.ts';
import { avatarFor, retainAvatars } from './avatar.ts';
import { ownedLaunchView } from './launch-phase-view.ts';
import { unreadMailCount } from './mail-count.ts';
interface SnapshotContext {
	sessions: ReadonlyMap<string, { agent: TeamAgent; launch: OwnedLaunch }>;
	reported: Set<string>;
	emit: (event: TeamEvent) => void;
	startedAt: string;
	selected: string;
}
export async function teamSnapshot(context: SnapshotContext): Promise<TeamSnapshot> {
	const agents: TeamAgent[] = [];
	const slugs = new Set([
		...(await listAgentSlugs()),
		...[...context.sessions]
			.filter(([, session]) => session.agent.status === 'running')
			.map(([slug]) => slug),
	]);
	retainAvatars(slugs);
	for (const slug of slugs) {
		const entry = `${slug}.json`;
		const session = context.sessions.get(slug);
		try {
			const record = await loadAgent(slug);
			if (!record) {
				if (session?.agent.status !== 'running') continue;
				throw new Error('Registration is unavailable for an owned running session.');
			}
			let activity = await readActivity(slug);
			const headDown = await headDownView(slug);
			// The roster observes committed state; wake and stop paths revalidate under the lock.
			const rest = await readRest(slug);
			const unreadMail = await unreadMailCount(slug);
			const avatar = await avatarFor(slug);
			const modelInfo = await refreshModelInfo(slug, record);
			const phaseError = `launch:${slug}`;
			if (
				session?.agent.status === 'running' &&
				session.agent.provider === 'grok' &&
				activity?.nonce === session.launch.nonce &&
				activity.launch?.phase === 'connecting'
			) {
				try {
					activity = await observeGrokSession(
						slug,
						session.launch.nonce,
						modelInfo,
						() =>
							context.sessions.get(slug) === session &&
							session.agent.status === 'running',
					);
					context.reported.delete(phaseError);
				} catch {
					if (!context.reported.has(phaseError)) {
						context.reported.add(phaseError);
						context.emit({
							type: 'error',
							source: 'launch',
							slug,
							message:
								'Launch phase update could not be saved; current status retained.',
						});
					}
				}
			} else context.reported.delete(phaseError);
			const current =
				!session || activity?.nonce === session.launch.nonce ? activity : undefined;
			const launch =
				session?.agent.status === 'running'
					? ownedLaunchView(session.launch, activity)
					: undefined;
			const native =
				session?.agent.status === 'running' &&
				session.agent.provider === 'claude' &&
				current?.nonce === session.launch.nonce
					? await claudeTurn(slug, session.launch.nonce)
					: undefined;
			const progress = await roomProgress(slug);
			agents.push({
				...(session?.agent ?? {
					slug,
					name: record.name,
					provider: record.provider,
					cwd: record.cwd,
					...(record.provider === 'claude'
						? {
								claudeConfigDir: claudeConfigDirectory(record),
								claudeConfigInherited: record.claudeConfigDir === undefined,
							}
						: {}),
					status: (await isAgentRunning(slug)) ? 'elsewhere' : 'offline',
				}),
				workingOn: current?.workingOn ?? '',
				...(context.sessions.get(slug) === session &&
				native?.attached &&
				native.compactions > 0
					? { nativeCompacting: true as const }
					: {}),
				...(launch ? { launch } : {}),
				name: memberLabel(record),
				memberType: record.memberType ?? 'teammate',
				...(headDown ? { headDown } : {}),
				canManageHeadDown: await canManageHeadDown(slug),
				...(modelInfo ? { modelInfo } : {}),
				...(progress ? { roomProgress: progress } : {}),
				...(rest?.mode === 'ready' && (!session || rest.nonce === session.launch.nonce)
					? { restConfirmation: rest.id }
					: {}),
				ownedSession: session?.agent.status === 'running',
				...(record.hibernation?.active ? { status: 'hibernated' as const } : {}),
				expertise: record.expertise,
				domain: record.domain ?? '',
				coveredBy: record.backup ?? '',
				activity: current?.state ?? 'idle',
				unreadMail,
				...(avatar ? { avatar } : {}),
			});
			context.reported.delete(entry);
		} catch (error: unknown) {
			if (session?.agent.status === 'running' && context.sessions.get(slug) === session) {
				agents.push({
					...session.agent,
					ownedSession: true,
					observationUnavailable: true,
				});
			}
			if (!context.reported.has(entry)) {
				context.reported.add(entry);
				context.emit({
					type: 'error',
					message: `Cannot load ${entry}: ${error instanceof Error ? error.message : String(error)}`,
				});
			}
		}
	}
	const buildNumber = Number(release().split('.')[2]);
	return {
		startedAt: context.startedAt,
		agents,
		selected: context.selected,
		...(process.platform === 'win32' && Number.isSafeInteger(buildNumber)
			? {
					windowsPty: {
						backend: buildNumber >= 18309 ? ('conpty' as const) : ('winpty' as const),
						buildNumber,
					},
				}
			: {}),
	};
}
