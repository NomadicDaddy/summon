import { ipcMain } from 'electron';

import { runtimeFaultInput } from '../runtime-fault-model.ts';
import { runtimeFaultDelivery } from './runtime-fault-delivery.ts';

export function runtimeFaultIpc(
	trusted: (event: Electron.IpcMainInvokeEvent) => void,
	delivery: ReturnType<typeof runtimeFaultDelivery>,
): void {
	ipcMain.handle('team:fault-report', async (event, input: unknown) => {
		trusted(event);
		await delivery.report(runtimeFaultInput.parse(input));
	});
}
