import type { BoardSnapshot } from '../board-model.ts';
import type { BoardMove } from './types.ts';

import { updateBoardItem } from '../board.ts';
import { CommunicationRefreshError } from '../communication-gate.ts';
import { sendCliMessage } from '../local-room-access.ts';
import { operatorOnly } from '../mail-identity.ts';

// Named moves keep arbitrary fields out of the renderer's write surface.
const moves: Record<BoardMove, Record<string, unknown>> = {
	approve: { state: 'done' },
	archive: { archived: true },
	backlog: { state: 'backlog' },
	unblock: { blockedOn: null, state: 'ready' },
};

function isMove(value: unknown): value is BoardMove {
	return typeof value === 'string' && Object.hasOwn(moves, value);
}

export async function moveBoard(
	id: unknown,
	revision: unknown,
	move: unknown,
): Promise<BoardSnapshot> {
	operatorOnly();
	if (typeof id !== 'string' || !isMove(move)) throw new Error('Invalid board move.');
	if (typeof revision !== 'number' || !Number.isSafeInteger(revision))
		throw new Error('Invalid item revision.');
	const snapshot = await updateBoardItem(id, revision, moves[move]).catch((error: unknown) => {
		if (error instanceof CommunicationRefreshError)
			throw new Error(`Board change was not saved. ${error.message}`);
		throw error;
	});
	if (move !== 'approve' && move !== 'unblock') return snapshot;
	const item = snapshot.items.find((candidate) => candidate.id === id);
	if (!item || item.owner === '') return snapshot;
	// Titles are data, not additional wake targets. Keep only the owner's explicit mention.
	const title = item.title.replace(/@/g, '');
	const decision = move === 'approve' ? 'accepted completed work' : 'go ahead';
	try {
		// CLI attribution directs the wake without impersonating a human instruction. The
		// operator decision itself remains recorded in board history at this item revision.
		await sendCliMessage(`@${item.owner} ${decision}: ${title} (board ${id})`);
	} catch {
		// Do not roll back a saved decision or silently retry: delivery may be uncertain.
		throw new Error(
			`Board decision saved (${item.state}): ${title}. Chat notification failed; ` +
				`check the room and tell ${item.owner} if missing. Do not repeat the board move.`,
		);
	}
	return snapshot;
}
