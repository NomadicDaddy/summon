import type { SessionTransitionInput } from '../session-history.ts';
import type { killProcessTree } from './pty-process.ts';
import type { sessionTransitions } from './session-transitions.ts';
import type { Team } from './team.ts';

import { tryGracefulStop } from './graceful-stop.ts';

export async function stopOwnedSession(
	team: Team,
	slug: string,
	reason: SessionTransitionInput['reason'],
	history: ReturnType<typeof sessionTransitions>,
	terminate: typeof killProcessTree,
	ended: (session: NonNullable<ReturnType<Team['sessions']['get']>>) => void,
): Promise<void> {
	const session = team.sessions.get(slug);
	if (session?.agent.status !== 'running') return;
	const running = (): boolean =>
		team.sessions.get(slug) === session && session.agent.status === 'running';
	session.stopRequested = true;
	session.stopReason = reason;
	await history.recordSession(session, 'stop-requested', reason);
	try {
		await tryGracefulStop(session, () => team.sessions.get(slug) === session);
		if (!running()) return;
		if (process.platform === 'win32') {
			await terminate(session.pty.pid, () => session.agent.status !== 'running');
			// ConPTY may delay its callback after confirmed process-tree termination.
			ended(session);
		} else session.pty.kill();
	} catch (error) {
		session.stopRequested = false;
		delete session.stopReason;
		await history.recordSession(session, 'stop-failed', reason);
		throw error;
	}
}
