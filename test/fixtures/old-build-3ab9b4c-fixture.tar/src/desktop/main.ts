import { app, ipcMain, shell } from 'electron';
import { spawn } from 'node-pty';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import type { TeamEvent } from './types.ts';

import { communicationState } from '../communication-state.ts';
import { requireExecutable } from '../executable.ts';
import { sendHuman } from '../local-room-access.ts';
import { localPage, localTail } from '../local-room.ts';
import { stopForRest } from '../rest.ts';
import { answerRoom } from '../room-question-access.ts';
import { appendRuntimeFault } from '../runtime-faults.ts';
import { slugFor } from '../store.ts';
import { initialMentionCursor } from '../team-mentions.ts';
import { readTeamSettings, type TeamSettings } from '../team-settings.ts';
import { readTeamStartup, recordTeamStartup, teamWindowRuntime } from '../team-startup.ts';
import { assertNonElevated } from '../windows-integrity.ts';
import { boardIpc } from './board-ipc.ts';
import { diaryIpc } from './diary-ipc.ts';
import { headDownIpc } from './head-down-ipc.ts';
import { maintenanceIpc } from './maintenance-ipc.ts';
import { notepadIpc } from './notepad-ipc.ts';
import { DEFAULT_HOLD_POLICY } from './notification-pause.ts';
import { registerOperatorIpc } from './operator-ipc.ts';
import { trackOperatorView } from './operator-view.ts';
import { OperatorTerminal } from './operator.ts';
import { reposIpc } from './repos-ipc.ts';
import { persistImage, roomImageIpc } from './room-images.ts';
import { roomLinkIpc } from './room-link-ipc.ts';
import { runtimeFaultDelivery } from './runtime-fault-delivery.ts';
import { runtimeFaultIpc } from './runtime-fault-ipc.ts';
import { detectShells } from './shells.ts';
import { createTeamTimers } from './team-timers.ts';
import { Team } from './team.ts';
import { typingKey } from './typing-key.ts';
import { createWindowShutdown } from './window-shutdown.ts';
import { createTeamWindow } from './window.ts';

if (process.platform === 'win32') process.env.NoDefaultCurrentDirectoryInExePath = '1';
const [root, bun, cli, receipt] = process.argv.slice(2);
if (!root || !bun || !cli || process.env.SUMMON_AGENT)
	throw new Error('Open the team window from your own terminal with summon --team.');
process.env.SUMMON_HOME = resolve(root);
await mkdir(teamWindowRuntime(), { recursive: true, mode: 0o700 });
app.setPath('userData', teamWindowRuntime());
app.setName('summon');
if (!app.requestSingleInstanceLock()) {
	if (receipt) await writeFile(receipt, '{}');
	app.quit();
} else {
	void app
		.whenReady()
		.then(async () => {
			await assertNonElevated();
			let ready = false;
			let quitting = false;
			const events: TeamEvent[] = [];
			const delivery = runtimeFaultDelivery(
				() => team.startedAt,
				(event) => {
					if (event.type === 'snapshot') viewing.refresh();
					if (ready && !window.isDestroyed())
						window.webContents.send('team:event', event);
					else if (events.length < 1000) events.push(event);
				},
			);
			const team = new Team(requireExecutable(bun), cli, delivery.send, spawn);
			const mentionCursor = await initialMentionCursor();
			const previousTeamStart = await readTeamStartup();
			await recordTeamStartup(team.startedAt);
			const timers = createTeamTimers({
				team,
				send: (event) => window.webContents.send('team:event', event),
				canSend: () => ready && !window.isDestroyed(),
				halted: () => quitting,
				initialCursor: mentionCursor,
				previousTeamStart,
			});
			timers.start();
			const focus = async (): Promise<void> => {
				if (quitting) return;
				if (window.isMinimized()) window.restore();
				window.show();
				window.focus();
				await team.publish();
			};
			app.on('second-instance', () => {
				if (ready) void focus().catch((error: unknown) => team.error(error));
			});
			const window = createTeamWindow((error) => team.error(error));
			// The automatic hold follows the team settings (Phillip #7266); a save refreshes it.
			let holdPolicy = DEFAULT_HOLD_POLICY;
			const applyHoldPolicy = (settings: TeamSettings): void => {
				holdPolicy = { autoHold: settings.autoHold, holdMs: settings.holdSeconds * 1000 };
			};
			applyHoldPolicy(await readTeamSettings());
			const viewing = trackOperatorView(
				window,
				() => team.selected,
				(name) => team.sessions.get(name)?.agent.status === 'running',
				(error) => team.error(error),
				() => holdPolicy,
			);
			team.notificationPause = viewing.view;
			// A modifier or a window-switch chord is not typing at a teammate; see typing-key.ts.
			window.webContents.on('before-input-event', (_event, input) => {
				if (input.type === 'keyDown' && typingKey(input)) viewing.typing(team.selected);
			});
			const trusted = (event: Electron.IpcMainEvent | Electron.IpcMainInvokeEvent): void => {
				if (
					event.sender !== window.webContents ||
					event.senderFrame !== window.webContents.mainFrame
				)
					throw new Error('Unknown team window.');
			};
			const shells = await detectShells();
			ipcMain.handle('team:pause-notifications', async (event, paused: unknown) => {
				trusted(event);
				if (typeof paused !== 'boolean') throw new Error('Invalid notification pause.');
				await viewing.set(paused);
				await team.publish();
			});
			maintenanceIpc(team, trusted, (settings) => {
				applyHoldPolicy(settings);
				viewing.refresh();
			});
			runtimeFaultIpc(trusted, delivery);
			boardIpc(trusted);
			diaryIpc(trusted);
			headDownIpc(trusted);
			notepadIpc(trusted);
			reposIpc(trusted, () => team.snapshot());
			roomImageIpc(trusted);
			roomLinkIpc(trusted);
			ipcMain.handle('team:open-repository', (event) => {
				trusted(event);
				return shell.openExternal('https://github.com/NomadicDaddy/summon');
			});
			const operator = new OperatorTerminal(
				shells,
				process.cwd(),
				(event) => {
					if (!window.isDestroyed()) window.webContents.send('operator:event', event);
				},
				spawn,
			);
			registerOperatorIpc(operator, shells, trusted);
			ipcMain.handle('team:ready', async (event) => {
				trusted(event);
				ready = true;
				for (const message of events.splice(0))
					window.webContents.send('team:event', message);
				await focus().catch((error: unknown) => team.error(error));
				return team.snapshot();
			});
			ipcMain.handle('team:room-tail', async (event) => {
				trusted(event);
				return localTail(300);
			});
			ipcMain.handle(
				'team:room-answer',
				async (event, id: unknown, choice: unknown, text: unknown) => {
					trusted(event);
					if (
						typeof id !== 'number' ||
						(choice !== null && typeof choice !== 'number') ||
						(text !== undefined && typeof text !== 'string')
					)
						throw new Error('Invalid question answer.');
					return answerRoom(id, choice, text);
				},
			);
			ipcMain.handle('team:room-read', async (event, after: unknown) => {
				trusted(event);
				if (typeof after !== 'number') throw new Error('Invalid room cursor.');
				return { ...(await localPage(after)), paused: (await communicationState()).paused };
			});
			ipcMain.handle(
				'team:room-send',
				async (event, text: unknown, reply: unknown, image: unknown) => {
					trusted(event);
					if (
						typeof text !== 'string' ||
						!(
							reply === null ||
							(typeof reply === 'number' && Number.isSafeInteger(reply))
						)
					)
						throw new Error('Invalid room message.');
					return sendHuman(text, reply, await persistImage(image));
				},
			);
			ipcMain.handle(
				'team:stop-rest',
				async (event, name: unknown, confirmation: unknown) => {
					trusted(event);
					if (typeof name !== 'string' || typeof confirmation !== 'string')
						throw new Error('Invalid rest confirmation.');
					const slug = slugFor(name);
					if (team.sessions.get(slug)?.agent.status !== 'running')
						throw new Error(`${slug}: session is not running in this Team Window.`);
					await stopForRest(slug, confirmation, () => team.stop(slug, 'rest-work'));
					await team.publish();
				},
			);
			ipcMain.on('team:input', (event, name: unknown, data: unknown, humanInput: unknown) => {
				trusted(event);
				if (
					typeof name === 'string' &&
					typeof data === 'string' &&
					typeof humanInput === 'boolean'
				)
					void team
						.input(slugFor(name), data, humanInput)
						.catch((error: unknown) => team.error(error));
			});
			ipcMain.on('team:resize', (event, name: unknown, cols: unknown, rows: unknown) => {
				trusted(event);
				if (
					typeof name === 'string' &&
					typeof cols === 'number' &&
					typeof rows === 'number'
				)
					team.resize(slugFor(name), cols, rows);
			});
			const shutdown = createWindowShutdown({
				stopPolling: timers.stop,
				startPolling: timers.start,
				setClosing: (value) => {
					quitting = value;
				},
				stopSessions: () => [team.shutdown(), operator.shutdown()],
				recover: () => {
					team.closing = false;
					operator.cancelShutdown();
				},
				quit: () => {
					void delivery.flush().then(() => app.quit());
				},
				error: (error) => team.error(error),
			});
			window.on('close', shutdown.close);
			app.on('before-quit', shutdown.close);
			window.webContents.on('render-process-gone', (_event, details) => {
				void delivery
					.report({
						level: 'error',
						source: 'window.renderer-exit',
						text: `Renderer ended: ${details.reason}; exit code ${details.exitCode}.`,
					})
					.catch(() => {});
				void shutdown.request();
			});
			await window.loadFile(fileURLToPath(new URL('./index.html', import.meta.url)));
			window.show();
			if (receipt) await writeFile(receipt, '{}');
		})
		.catch(async (error: unknown) => {
			await appendRuntimeFault(
				{
					level: 'error',
					source: 'window.startup',
					text:
						error instanceof Error
							? error.message.slice(0, 8192)
							: 'Unclassified startup failure.',
				},
				new Date().toISOString(),
			).catch(() =>
				console.error(
					'Runtime error log unavailable; saving the startup diagnostic was not confirmed.',
				),
			);
			console.error(error);
			app.exit(1);
		});
}
