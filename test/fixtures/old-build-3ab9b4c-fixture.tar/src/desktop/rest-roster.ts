import type { TeamAgent } from './types.ts';

export function restRosterRow(
	agent: TeamAgent,
	member: HTMLButtonElement,
	stop: (slug: string, confirmation: string) => void,
): HTMLElement {
	if (!agent.restConfirmation || agent.status !== 'running') return member;
	const row = document.createElement('div');
	row.className = 'rest-row';
	const button = document.createElement('button');
	button.type = 'button';
	button.className = 'rest-stop';
	button.dataset.restSlug = agent.slug;
	button.textContent = 'Zzz';
	button.title = `${agent.name} confirmed ready to rest. Stop Session.`;
	button.setAttribute('aria-label', button.title);
	const confirmation = agent.restConfirmation;
	button.addEventListener('click', () => stop(agent.slug, confirmation));
	row.append(member, button);
	return row;
}

export function restoreRestFocus(roster: HTMLElement, name: string | undefined): void {
	if (!name) return;
	for (const button of roster.querySelectorAll<HTMLButtonElement>('.rest-stop'))
		if (button.dataset.restSlug === name) button.focus({ preventScroll: true });
}
