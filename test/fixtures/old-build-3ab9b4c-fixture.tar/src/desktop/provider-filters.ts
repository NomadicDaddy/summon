const providers = ['claude', 'codex', 'grok', 'kilo'] as const;
const storageKey = 'summon.hiddenProviders';

/** Local roster visibility only; session selection and lifecycle stay independent. */
export function setupProviderFilters(roster: HTMLElement): () => void {
	const container = document.getElementById('provider-filters');
	if (!container) throw new Error('Missing provider filters');
	const hidden = new Set<string>();
	const presence = document.getElementById('presence-filters');
	if (!presence) throw new Error('Missing presence filters');
	let mode = 'all';
	try {
		const savedMode = localStorage.getItem('summon.rosterPresence');
		if (savedMode === 'online' || savedMode === 'offline') mode = savedMode;
		const saved: unknown = JSON.parse(localStorage.getItem(storageKey) ?? '[]');
		if (Array.isArray(saved))
			for (const provider of providers) if (saved.includes(provider)) hidden.add(provider);
	} catch {
		// Unavailable or malformed storage must not prevent access to teammates.
	}
	const update = (): void => {
		for (const member of roster.querySelectorAll<HTMLElement>('.member')) {
			const online =
				member.classList.contains('running') || member.classList.contains('elsewhere');
			member.hidden =
				hidden.has(member.dataset.provider ?? '') ||
				(mode === 'online' && !online) ||
				(mode === 'offline' && online);
		}
		for (const button of presence.querySelectorAll('button'))
			button.setAttribute('aria-pressed', String(button.dataset.presence === mode));
		for (const button of container.querySelectorAll('button')) {
			const provider = button.dataset.provider ?? '';
			button.setAttribute('aria-pressed', String(!hidden.has(provider)));
			button.title = `${hidden.has(provider) ? 'Show' : 'Hide'} ${button.getAttribute('aria-label')}`;
		}
	};
	for (const provider of providers) {
		const button = document.createElement('button');
		button.type = 'button';
		button.dataset.provider = provider;
		button.textContent = providerLabels[provider].short;
		button.setAttribute('aria-label', `${providerLabels[provider].name} teammates`);
		button.setAttribute('aria-controls', 'roster');
		button.addEventListener('click', () => {
			if (hidden.has(provider)) hidden.delete(provider);
			else hidden.add(provider);
			update();
			try {
				localStorage.setItem(storageKey, JSON.stringify([...hidden]));
			} catch {
				// Keep filtering usable for this window even when preferences cannot be saved.
			}
		});
		container.append(button);
	}
	for (const value of ['all', 'online', 'offline']) {
		const button = document.createElement('button');
		button.type = 'button';
		button.dataset.presence = value;
		button.textContent = value.slice(0, 1).toUpperCase() + value.slice(1);
		button.setAttribute('aria-controls', 'roster');
		button.title =
			value === 'offline'
				? 'Show stopped and hibernated teammates'
				: value === 'online'
					? 'Show teammates running here or elsewhere'
					: 'Show all session states';
		button.addEventListener('click', () => {
			mode = value;
			update();
			try {
				localStorage.setItem('summon.rosterPresence', mode);
			} catch {
				// Keep this window usable when preferences cannot be saved.
			}
		});
		presence.append(button);
	}
	update();
	return update;
}
import { providerLabels } from './provider-labels.ts';
