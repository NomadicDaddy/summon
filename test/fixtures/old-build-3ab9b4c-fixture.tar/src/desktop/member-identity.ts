import type { LaunchPhaseView } from '../launch-phase-model.ts';
import type { TeamAgent } from './types.ts';

import { headDownRow } from './head-down-row.ts';
import { labels, offlineTitle } from './hibernation-controls.ts';
import { setSweptLabel } from './letter-sweep.ts';
import { claudeAccountLabel } from './member-facts.ts';
import { memberIdentity } from './member-heading.ts';
import { COMPACTION_TITLE, nativeCompacting } from './native-compaction.ts';
import {
	observationUnavailable,
	UNAVAILABLE,
	UNAVAILABLE_NOTE,
} from './observation-unavailable.ts';

export function memberStatus(activity: string | undefined, fallback: string): string {
	return activity === 'busy' ? 'Busy' : activity === 'needs-user' ? 'Needs you' : fallback;
}

/*
 * LAUNCH PHASES (card 0674e3b6). From the moment a session process is spawned until the member's
 * first explicit status call, the row used to read "Ready" with a green dot: the one stretch in
 * which nothing is ready. The main process now says which of three phases the launch is in, with
 * the observation that put it there. The phase is a fact beside the self-reported state, never a
 * value of it: Busy and Needs you are things the member said and always win; the phase only
 * replaces the idle fallback. "Logging in" means the CLI showed itself, and the tooltip says so in
 * as many words - Summon never checks sign-in.
 */
const launchLabels: Record<LaunchPhaseView['phase'], string> = {
	connecting: 'Connecting…',
	'logging-in': 'Logging in…',
	startup: 'Summon startup…',
};
const launchEvidence: Record<LaunchPhaseView['evidence'], string> = {
	'owned-process-spawn': 'The session process has started; waiting for the CLI to show itself.',
	'claude-mcp-initialized': 'Claude initialised its MCP connection.',
	'codex-session-start': 'Codex reported its session start.',
	'grok-session-metadata': 'Grok wrote fresh session metadata for this launch.',
	'kilo-owned-session': 'Kilo answered for its own session.',
	'mail-readiness': 'Mail readiness was acknowledged for this launch.',
};
const NO_LOGIN_CLAIM = 'Sign-in is not checked by Summon; the CLI handles it.';

/** The phase name without its ellipsis, for sentences. */
function phaseName(view: LaunchPhaseView): string {
	return launchLabels[view.phase].replace('…', '');
}

/** The row's wording for an active launch, or undefined when the owned session has none. */
export function launchLabel(agent: Pick<TeamAgent, 'launch' | 'status'>): string | undefined {
	return agent.status === 'running' && agent.launch
		? launchLabels[agent.launch.phase]
		: undefined;
}

export function launchTooltip(view: LaunchPhaseView): string {
	const since = new Date(view.since).toLocaleTimeString();
	const lines = [`${phaseName(view)} since ${since}.`, launchEvidence[view.evidence]];
	if (view.phase === 'logging-in') lines.push(NO_LOGIN_CLAIM);
	if (view.phase === 'startup') lines.push('Waiting for the first status call.');
	return lines.join('\n');
}

/** A sentence for a session that ended before its first status call, or empty. */
export function launchEndedNote(agent: Pick<TeamAgent, 'launchEnded' | 'status'>): string {
	// Only an ended session owns this note: elsewhere means another window is running it now.
	const view = agent.launchEnded;
	if (!view || agent.status !== 'exited') return '';
	return `Ended while ${phaseName(view).toLowerCase()} (${launchEvidence[view.evidence]})`;
}

/**
 * One label for the roster row and the session header. Busy and Needs you first, then the launch
 * phase, then the session state - so the two surfaces can never disagree about a member.
 */
export function memberStateLabel(agent: TeamAgent): string {
	if (observationUnavailable(agent)) return UNAVAILABLE;
	if (nativeCompacting(agent)) return 'Compacting…';
	const online = agent.status === 'running' || agent.status === 'elsewhere';
	const activity = online ? agent.activity : undefined;
	return memberStatus(activity, launchLabel(agent) ?? labels[agent.status]);
}

/**
 * The session header's state in one place: its class (the session state, busy when self-reported,
 * plus the launch phase for the ring), the same label the row shows, and the phase tooltip.
 */
export function headerState(
	agent: TeamAgent | undefined,
	activity: string | undefined,
): { className: string; label: string; title: string } {
	const unavailable = !!agent && observationUnavailable(agent);
	const compacting = !unavailable && nativeCompacting(agent);
	const state =
		(activity === 'busy' || compacting) && !unavailable ? 'busy' : (agent?.status ?? '');
	const launching = agent && !unavailable && launchLabel(agent) ? agent.launch : undefined;
	return {
		className: [state, launching ? `launch-${launching.phase}` : ''].filter(Boolean).join(' '),
		label: agent ? memberStateLabel(agent) : '',
		title: compacting
			? COMPACTION_TITLE
			: launching
				? launchTooltip(launching)
				: unavailable
					? UNAVAILABLE_NOTE
					: '',
	};
}

/**
 * Write a state label, with its letters lit in turn while the member is compacting (#8406). The
 * roster row and the session header both come through here, so they animate alike and in step.
 */
export function writeStateLabel(
	element: HTMLElement,
	agent: TeamAgent | undefined,
	label = agent ? memberStateLabel(agent) : '',
): void {
	const compacting = !!agent && !observationUnavailable(agent) && nativeCompacting(agent);
	setSweptLabel(element, label, compacting);
	const tone = stateTone(label);
	if (tone) element.dataset['tone'] = tone;
	else delete element.dataset['tone'];
}

/**
 * The colour a state word shares with its dot (Phillip #8525, #8530): Ready is the green of a
 * running session's dot and Busy the amber of a working one. Every other word stays neutral.
 */
export function stateTone(label: string): 'busy' | 'ready' | undefined {
	if (label === 'Busy') return 'busy';
	return label === labels.running ? 'ready' : undefined;
}

/** A teammate's self-reported task, or Ready when they have not set one or it says nothing. */
export function statusText(value?: string): string {
	const task = value?.trim();
	return !task || /^(available|not set)$/i.test(task) ? 'Ready' : task;
}

/**
 * Omit a Ready task that repeats the current owned-session state. Under a launch phase the line
 * is empty whatever the record says: the task text is the previous launch's or the default, and
 * neither is something this launch has said yet.
 */
export function memberWorkingText(agent: TeamAgent): string {
	if (observationUnavailable(agent) || launchLabel(agent)) return '';
	const task = statusText(agent.workingOn);
	return agent.status === 'running' && agent.activity === 'idle' && task === 'Ready' ? '' : task;
}

/**
 * Build one roster row. Returned inert - the caller owns selection, focus and pane creation,
 * because those are window state rather than anything about the teammate.
 */
export function memberRow(agent: TeamAgent, selected: string): HTMLButtonElement {
	const button = document.createElement('button');
	button.className = `member ${agent.status}`;
	button.dataset.slug = agent.slug;
	button.dataset.provider = agent.provider;
	button.title = [
		agent.expertise?.trim() ? `Expertise: ${agent.expertise.trim()}` : '',
		agent.domain?.trim() ? `Domain: ${agent.domain.trim()}` : '',
	]
		.filter(Boolean)
		.join('\n\n');
	button.setAttribute('aria-current', String(agent.slug === selected));
	const avatar = document.createElement('span');
	avatar.className = 'avatar';
	avatar.textContent = agent.name.slice(0, 1).toUpperCase();
	if (agent.avatar) {
		const image = document.createElement('img');
		image.alt = '';
		image.src = agent.avatar;
		image.addEventListener(
			'error',
			() => {
				avatar.textContent = agent.name.slice(0, 1).toUpperCase();
			},
			{ once: true },
		);
		avatar.replaceChildren(image);
	}
	const description = document.createElement('span');
	const name = document.createElement('strong');
	name.textContent = agent.name;
	const detail = document.createElement('small');
	const online = agent.status === 'running' || agent.status === 'elsewhere';
	const unavailable = observationUnavailable(agent);
	const activity = online && !unavailable ? agent.activity : undefined;
	button.classList.toggle(
		'busy',
		activity === 'busy' || (!unavailable && nativeCompacting(agent)),
	);
	button.classList.toggle('needs-user', activity === 'needs-user');
	writeStateLabel(detail, agent);
	// The phase rides on the row as data, the way head-down does, so the dot's ring is styled
	// from it and a probe can read it; the observation that set it lives in the tooltip.
	if (unavailable) {
		button.dataset.observation = 'unavailable';
		detail.title = UNAVAILABLE_NOTE;
	} else if (nativeCompacting(agent)) {
		detail.title = COMPACTION_TITLE;
	} else if (launchLabel(agent) && agent.launch) {
		button.dataset.launchPhase = agent.launch.phase;
		detail.title = launchTooltip(agent.launch);
	} else {
		const ended = launchEndedNote(agent);
		if (ended) detail.title = ended;
	}
	description.append(name, detail);
	if (agent.provider === 'claude' && agent.claudeConfigDir) {
		const account = document.createElement('small');
		account.className = 'member-account';
		account.textContent = claudeAccountLabel(agent);
		account.title = `Claude configuration directory: ${agent.claudeConfigDir}. The signed-in identity is managed in Claude.`;
		description.append(account);
	}
	const working = document.createElement('small');
	working.className = 'working-on';
	/*
	 * HEAD-DOWN REPLACES THE SELF-WRITTEN LINE rather than sitting beside it. The roster column is
	 * 252px and will not carry two texts legibly, and between the two the goal is the one the
	 * operator agreed to - the teammate's own status stays readable in the tooltip.
	 *
	 * The modifier goes on the row, never on the dot's colour: head-down is something a teammate is
	 * doing, not something it has become, so the dot keeps reporting whether the session is alive.
	 */
	const headDown = agent.headDown;
	const active = headDown?.phase === 'active' ? headDown : undefined;
	const self = unavailable ? UNAVAILABLE_NOTE : statusText(agent.workingOn);
	const row = headDownRow(agent.status, self, headDown);
	working.textContent = row.phase ? row.line : memberWorkingText(agent);
	if (row.phase) button.dataset.headDown = row.phase;
	button.classList.toggle('overdue', row.overdue);
	working.title = [
		active ? `Head-down: ${active.goal}` : '',
		active ? `Done when: ${active.completion}` : '',
		active?.approvedBy ? `Approved by ${active.approvedBy}` : '',
		active?.overdue ? 'Heartbeat overdue - the session has stopped reporting' : '',
		headDown?.phase === 'requested' ? `Head-down requested: ${headDown.goal}` : '',
		active ? `Its own status: ${self}` : self,
		button.title,
	]
		.filter(Boolean)
		.join('\n\n');
	description.append(working);
	const badges = document.createElement('span');
	badges.className = 'member-badges';
	if (activity === 'needs-user') {
		const hand = document.createElement('span');
		hand.textContent = '✋';
		hand.title = 'Needs your attention';
		hand.setAttribute('aria-label', hand.title);
		badges.append(hand);
	}
	if (agent.unreadMail) {
		const mail = document.createElement('span');
		mail.className = 'mail-count';
		mail.textContent = `✉ ${agent.unreadMail}`;
		mail.title = `${agent.unreadMail} unread mail message(s)`;
		mail.setAttribute('aria-label', mail.title);
		badges.append(mail);
	}
	const identity = memberIdentity(avatar, name, badges, agent);
	if (agent.memberType === 'pm') name.after(roleTag());
	const dot = document.createElement('span');
	dot.className = 'dot';
	// Distinguish sessions that ended from teammates never started, and name the phase a session
	// ended in when it never got as far as speaking.
	const launching = unavailable ? undefined : launchLabel(agent);
	dot.title = online
		? !unavailable && nativeCompacting(agent)
			? COMPACTION_TITLE
			: activity === 'busy'
				? 'Busy (self-reported)'
				: launching
					? `Launching: ${launching}`
					: unavailable
						? 'Running; status unavailable'
						: 'Online'
		: [offlineTitle(agent), launchEndedNote(agent)].filter(Boolean).join(' — ');
	button.append(identity, description, dot);
	return button;
}

/**
 * The PM's role, beside the name rather than among the badges: the badges are things to act on
 * (a raised hand, unread mail), and this is who the member is. Text rather than colour carries it,
 * and the abbreviation expands on hover. The session header spells it out in full (#5734).
 */
function roleTag(): HTMLElement {
	const tag = document.createElement('abbr');
	tag.className = 'role-tag';
	tag.textContent = 'PM';
	tag.title = 'Project manager';
	return tag;
}
