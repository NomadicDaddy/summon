import type { TeamAgent } from './types.ts';

import { leadWithSetup } from './provider-setup-view.ts';

export function renderWelcome(
	get: (id: string) => HTMLElement,
	selected: TeamAgent | undefined,
	addedSlug: string,
	noTeammates: boolean,
): void {
	const empty = get('empty');
	const start = get('start');
	const unavailable = selected?.status === 'elsewhere' || selected?.status === 'hibernated';
	empty.classList.toggle('is-state', unavailable);
	if (selected?.status === 'elsewhere') {
		empty.hidden = false;
		get('empty-title').textContent = 'Already running elsewhere.';
		get('empty-detail').textContent =
			'Use the existing terminal. This window will not start a duplicate or stop that session.';
	} else if (selected?.status === 'hibernated') {
		get('empty-title').textContent = `${selected.name} is hibernated.`;
		get('empty-detail').textContent =
			'Use Unhibernate to allow work and pending messages again.';
	} else if (selected?.slug === addedSlug && selected.status === 'offline') {
		get('empty-title').textContent = `${selected.name} has been added.`;
		get('empty-detail').textContent =
			`Nothing is running yet. Start ${selected.name} to open their session in this window.`;
	} else {
		get('empty-title').textContent = selected
			? `Ready for ${selected.name}.`
			: 'Your team, where you need them.';
		get('empty-detail').textContent = noTeammates
			? 'Each teammate is a coding-agent CLI with its own working folder and saved conversation. You will need at least one supported CLI installed and signed in.'
			: 'Summon a teammate here to resume their saved conversation.';
	}
	const emptyStart = get('empty-start');
	emptyStart.hidden = !noTeammates && (start.hidden || empty.hidden);
	emptyStart.textContent = noTeammates
		? 'Add your first teammate'
		: selected?.slug === addedSlug && selected.status === 'offline'
			? `Start ${selected.name}`
			: start.textContent;
	// What is installed here, and the way to the guide, belong to the first run only: once there is a
	// teammate the same answer lives in Maintenance, and the empty window is about that teammate.
	get('empty-cli').hidden = !noTeammates;
	get('empty-setup').hidden = !noTeammates;
	leadWithSetup(get);
}
