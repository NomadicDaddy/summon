import { readActivity } from './agent-activity.ts';
import { readBoard } from './board.ts';
import { cachedLocalEvents } from './local-room.ts';
import { ownHolds } from './mail-attention.ts';
import { optionalText } from './mail-files.ts';
import { header, statePath } from './mail-read.ts';
import { pendingMessages } from './mailbox.ts';
import { localCursorPath, roomCursor } from './room-cursor.ts';
import { directlyAddressed } from './room-wake.ts';
import { scheduledRestReason } from './schedule-summary.ts';
import { listSchedules } from './schedules.ts';

export async function restEvidence(name: string, since?: number) {
	const cards = (await readBoard()).items.filter((item) => item.owner === name && !item.archived);
	const board = JSON.stringify({
		cards: cards.map((item) => [item.id, item.revision]),
		decisions: (await ownHolds(name)).map((hold) => [hold.id, hold.decision]),
	});
	const history = await cachedLocalEvents();
	const own = new Set(
		history
			.filter((event) => event.sender.kind === 'agent' && event.sender.id === name)
			.map((event) => event.id),
	);
	const after = since ?? roomCursor((await optionalText(localCursorPath(name))) ?? '0');
	const addressed = history.find(
		(event) =>
			event.id > after &&
			!(event.sender.kind === 'agent' && event.sender.id === name) &&
			(directlyAddressed(event.text, name) ||
				(event.replyTo !== null && own.has(event.replyTo))),
	);
	let mail = false;
	for (const file of await pendingMessages(name)) {
		const id = file.slice(0, -3);
		// These are protocol bookkeeping, retained for the next ordinary read, not new work.
		const item = await header(name, id);
		if (['receipt', 'confirmation'].includes(item.kind) || item.noticeStatus === 'obsolete')
			continue;
		if (!(await optionalText(statePath(name, id, 'read')))) {
			mail = true;
			break;
		}
	}
	const scheduled = scheduledRestReason(await listSchedules(), name);
	const activity = await readActivity(name);
	const reason =
		activity?.state !== 'idle'
			? 'Activity is not idle'
			: cards.some((item) => ['ready', 'doing'].includes(item.state))
				? 'Ready or Doing cards need attention'
				: mail
					? 'Unread mail needs attention'
					: scheduled
						? scheduled
						: addressed
							? `Room message #${addressed.id} after acknowledged cursor #${after} addresses you. Read summon --checkpoint, then pass each receipt only after reading its batch`
							: '';
	return { board, through: history.at(-1)?.id ?? 0, reason, nonce: activity?.nonce };
}
