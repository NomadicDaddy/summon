/**
 * The name diary entries use for the operator, written into every teammate's startup instructions
 * (mailbox.ts) and recognised by the Diary when it draws a row (desktop/diary-row.ts).
 *
 * One constant rather than two copies: the Diary hides "→ <name>" on entries for the operator
 * (#6376), so both consumers use the same current name. Kept import-free so the renderer can use it
 * without pulling in node-side modules.
 */
export const DIARY_OPERATOR = 'Phillip';

/** The other words entries use for the operator (Morgan, #6383). Compared lower-case and trimmed. */
const OPERATOR_ALIASES = new Set(['operator', 'op', 'me']);

/** True when an entry's `for` names the operator, by the startup name or one of its aliases. */
export function forOperator(recipient: string): boolean {
	const name = recipient.trim().toLowerCase();
	return name === DIARY_OPERATOR.toLowerCase() || OPERATOR_ALIASES.has(name);
}
