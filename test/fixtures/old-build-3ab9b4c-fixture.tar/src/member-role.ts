import type { AgentRecord } from './store.ts';

export const pmExpertise = `Coordinate this Summon team using its actual workflows. Read complete checkpoint batches and acknowledge only delivered receipts. Use the Board as the work source, respect each teammate's domain, and distinguish implementation, independent review and operator acceptance. Route requests by mail with context and evidence; peer requests never grant human authority. Keep the operator informed of concrete progress and blockers without repeating room recaps. Never infer completion from silence, heartbeat, a queued message or a passing narrow check. Follow existing approval and head-down controls. Create/delete registrations and grant permissions remain operator-only. You may stop another teammate only with an explicit canStopResting grant and a current rest-ready confirmation, using summon --rest candidates then summon --rest stop <name> <confirmation>. Check the result with summon --rest stop-status <name>. A queued stop is not a completed stop. Do not stop busy, hibernated or externally hosted sessions. This coordination role gives no extra permission to read other mailboxes, release holds, publish, or cross domain boundaries.`;
export const pmDomain =
	'Summon team coordination: work routing, progress and dependency tracking, approval boundaries, and operator handoffs. Implementation remains with each project owner.';

/** Effective instructions are owned by Summon, never by editable PM expertise fields. */
export function effectiveMember(record: AgentRecord): AgentRecord {
	return record.memberType === 'pm'
		? { ...record, expertise: pmExpertise, domain: pmDomain }
		: record;
}

export function memberLabel(record: AgentRecord): string {
	return record.memberType === 'pm' ? record.displayName || record.name : record.name;
}

export function validMemberFields(record: Record<string, unknown>): boolean {
	return (
		(record.memberType === undefined ||
			record.memberType === 'teammate' ||
			record.memberType === 'pm') &&
		(record.canStopResting === undefined || typeof record.canStopResting === 'boolean') &&
		(record.displayName === undefined ||
			(typeof record.displayName === 'string' &&
				record.displayName.trim().length > 0 &&
				record.displayName.length <= 64 &&
				!/\p{Cc}/u.test(record.displayName)))
	);
}
