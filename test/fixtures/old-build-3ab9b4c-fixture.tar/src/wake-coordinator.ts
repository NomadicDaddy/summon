import { join } from 'node:path';

import type { CheckpointPackage } from './checkpoint-package-model.ts';
import type { WakeReceiverOptions } from './mail-watcher.ts';
import type { WakeStage } from './wake-errors.ts';
import type { WakePart } from './wake-part.ts';

import { automaticNoticeSuppressed } from './automatic-notice.ts';
import { communicationState } from './communication-state.ts';
import { deliverHibernationControl } from './hibernation.ts';
import { prepareLocalRoomNotice } from './local-room-live.ts';
import { optionalText } from './mail-files.ts';
import { prepareHoldNotice, prepareMailNotice, prepareReadiness } from './mail-notice.ts';
import {
	awaitingReadinessReason,
	deliveryStatus,
	runtimePath,
	saveDelivery,
} from './mail-session.ts';
import { NotificationNotSentError } from './notification-delivery.ts';
import { pollWakeTelegram, prepareTelegramNotice } from './telegram-live.ts';
import { wakeDeliveryStatus } from './wake-delivery-store.ts';
import { deliverWakeParts } from './wake-delivery.ts';
import { recoverWakeError, retainWakeError } from './wake-errors.ts';
import { activeWakeReadBoundary } from './wake-read-boundary.ts';

function covered(part: WakePart, packet: CheckpointPackage): boolean {
	const target = part.target;
	if (target.source === 'room') return target.through <= packet.sources.room.through;
	if (target.source === 'telegram')
		return (
			packet.sources.telegram?.key === target.key &&
			target.through <= packet.sources.telegram.through
		);
	if (target.source === 'mail')
		return target.ids.every((id) =>
			packet.items.some((item) => item.source === 'mail' && item.id === id),
		);
	if (target.source === 'holds')
		return target.ids.every((key) => {
			const [, id, fingerprint] = key.split(':');
			return !!id && !!fingerprint && packet.sources.holds[id] === fingerprint;
		});
	return false;
}

/** One serialized cycle per receiver lease; independent inventory failures preserve healthy wakes. */
export function createWakeCoordinator(
	name: string,
	nonce: string,
	send: (text: string) => Promise<void>,
	active: () => boolean,
	owns: () => Promise<boolean>,
	options: WakeReceiverOptions,
): () => Promise<void> {
	const startedAt = Date.now();
	const report = async (stage: WakeStage, error: unknown): Promise<void> => {
		const retained = await retainWakeError(
			name,
			stage,
			new NotificationNotSentError('Notification inventory could not be read.', {
				cause: error,
			}),
		);
		if (retained.changed)
			console.error(`${name}: ${stage} remains queued; inspect own mail status.`);
	};
	return async () => {
		if (!active() || !(await owns())) return;
		// Import authenticated remote halt/proceed even while ordinary notifications are paused.
		let telegramFailed = false;
		try {
			await pollWakeTelegram(name);
		} catch (error: unknown) {
			telegramFailed = true;
			await report('telegram inventory', error);
		}
		if ((await communicationState()).paused) return;
		if (await deliverHibernationControl(name, nonce, options.controlSend ?? send)) return;
		if (await automaticNoticeSuppressed(name)) return;
		if (options.noticeAllowed && !(await options.noticeAllowed())) return;
		let packet: CheckpointPackage | undefined;
		try {
			packet = await activeWakeReadBoundary(name, startedAt);
		} catch (error: unknown) {
			await report('checkpoint inventory', error);
			await saveDelivery(name, {
				...(await deliveryStatus(name, nonce)),
				state: 'queued-only',
				reason: 'Active checkpoint inventory is invalid; inspect own wake errors.',
			});
			return;
		}
		const sources: { stage: WakeStage; collect: () => Promise<WakePart | undefined> }[] = [
			{ stage: 'mail inventory', collect: () => prepareReadiness(name, nonce) },
			{ stage: 'mail inventory', collect: () => prepareMailNotice(name, nonce, packet) },
			{ stage: 'approval inventory', collect: () => prepareHoldNotice(name, nonce, packet) },
			{ stage: 'room inventory', collect: () => prepareLocalRoomNotice(name, nonce, packet) },
			{
				stage: 'telegram inventory',
				collect: () => prepareTelegramNotice(name, nonce, packet),
			},
		];
		const results = await Promise.allSettled(sources.map((source) => source.collect()));
		const parts: WakePart[] = [];
		let failed = telegramFailed;
		const readiness = results[0];
		// A new natural event repeats the unconfirmed nonce, without a readiness-only loop.
		if (
			options.readinessReminder !== false &&
			readiness?.status === 'fulfilled' &&
			!readiness.value &&
			results.slice(1).some((value) => value.status === 'fulfilled' && value.value)
		) {
			try {
				readiness.value = await prepareReadiness(name, nonce, true);
			} catch (reason: unknown) {
				results[0] = { status: 'rejected', reason };
			}
		}
		for (const [index, result] of results.entries()) {
			const source = sources[index];
			if (!source) throw new Error('Notification inventory source is missing.');
			if (result.status === 'rejected') {
				failed = true;
				await report(source.stage, result.reason);
			} else if (result.value) parts.push(result.value);
		}
		if (!active() || (await automaticNoticeSuppressed(name))) return;
		// Recover a stage only when every collector for that stage succeeded, including readiness.
		for (const stage of new Set(sources.map((source) => source.stage))) {
			if (
				!(stage === 'telegram inventory' && telegramFailed) &&
				results.every(
					(result, index) =>
						sources[index]?.stage !== stage || result.status === 'fulfilled',
				)
			)
				await recoverWakeError(name, stage);
		}
		await recoverWakeError(name, 'checkpoint inventory');
		let result: 'none' | 'submitted' | 'uncertain' = 'none';
		try {
			result = await deliverWakeParts(name, nonce, parts, send, async () => {
				if (
					!active() ||
					!(await owns()) ||
					(options.noticeAllowed && !(await options.noticeAllowed()))
				)
					return false;
				const current = await activeWakeReadBoundary(name, startedAt);
				return !current || !parts.some((part) => covered(part, current));
			});
		} catch (error: unknown) {
			if (!(error instanceof NotificationNotSentError)) throw error;
			failed = true;
		}
		const ready = (await optionalText(join(runtimePath(name), `${nonce}.ready`))) === nonce;
		const delivery = await wakeDeliveryStatus(name, nonce);
		const uncertain =
			result === 'uncertain' ||
			delivery.unresolved.some(
				(value) => value.state === 'uncertain' || value.state === 'attempted',
			) ||
			delivery.more;
		failed ||= delivery.unresolved.some((value) => value.state === 'not-sent');
		if (!failed && !uncertain) await recoverWakeError(name, 'receiver cycle');
		await saveDelivery(name, {
			...(await deliveryStatus(name, nonce)),
			state: failed || uncertain ? 'queued-only' : ready ? 'live' : 'unconfirmed',
			reason: failed
				? 'A notification remains unsent; inspect own wake errors and delivery outcome.'
				: uncertain
					? 'Provider input may have begun; inspect the delivery outcome before retrying.'
					: ready
						? "Model confirmed receipt of this launch's notification."
						: awaitingReadinessReason,
		});
	};
}
