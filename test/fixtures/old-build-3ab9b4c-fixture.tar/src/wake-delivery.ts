import type { WakeOutcome } from './wake-delivery-store.ts';
import type { WakePart } from './wake-part.ts';

import { assertAutomaticNoticeAllowed } from './automatic-notice.ts';
import { checkpointHash } from './checkpoint-package-model.ts';
import { locked } from './mail-files.ts';
import { ownMailbox } from './mail-identity.ts';
import { NotificationNotSentError } from './notification-delivery.ts';
import {
	loadWakeOutcome,
	normalized,
	outcomePath,
	saveWakeOutcome,
} from './wake-delivery-store.ts';

/** The receiver owns serialization; retention precedes input and uncertain attempts never retry. */
export async function deliverWakeParts(
	name: string,
	nonce: string,
	parts: WakePart[],
	send: (text: string) => Promise<void>,
	allowed: () => Promise<boolean>,
): Promise<'none' | 'submitted' | 'uncertain'> {
	ownMailbox(name);
	const selected: WakePart[] = [];
	for (const part of parts)
		if ((await part.needed()) && !(await part.acknowledged())) selected.push(part);
	if (!selected.length) return 'none';
	const targets = normalized(selected.map((part) => part.target));
	const id = checkpointHash([name, nonce, targets]);
	return locked(`${outcomePath(name, id)}.lock`, async () => {
		const previous = await loadWakeOutcome(name, nonce, id);
		if (previous && !['not-sent', 'suppressed'].includes(previous.state)) return 'none';
		if (previous && previous.retryAt > Date.now()) return 'none';
		const now = new Date().toISOString();
		const value: WakeOutcome = {
			version: 1,
			id,
			owner: name,
			nonce,
			targets,
			state: 'attempted',
			stage: 'notification delivery',
			attempts: (previous?.attempts ?? 0) + 1,
			retryAt: 0,
			createdAt: previous?.createdAt ?? now,
			updatedAt: now,
			...(previous?.failedAt ? { failedAt: previous.failedAt } : {}),
			...(previous?.lastFailureAt ? { lastFailureAt: previous.lastFailureAt } : {}),
		};
		await saveWakeOutcome(value);
		let inputStarted = false;
		try {
			for (const part of selected) await part.mark('attempted');
			if (!(await allowed()))
				throw new NotificationNotSentError('Receiver ownership or read boundary changed.');
			for (const part of selected) {
				if (!(await part.needed()) || (await part.acknowledged())) {
					// No input has happened. Retain this as suppression, not a read acknowledgment.
					value.state = 'suppressed';
					value.updatedAt = new Date().toISOString();
					await saveWakeOutcome(value);
					for (const pending of selected) await pending.mark('deferred');
					return 'none';
				}
			}
			await assertAutomaticNoticeAllowed(name);
			inputStarted = true;
			await send(selected.map((part) => part.text).join('\n'));
			value.state = 'provider-submitted';
			value.updatedAt = new Date().toISOString();
			if (value.failedAt) value.recoveredAt = value.updatedAt;
			await saveWakeOutcome(value);
			for (const part of selected) await part.mark('queued');
			return 'submitted';
		} catch (error: unknown) {
			const unsent = !inputStarted || error instanceof NotificationNotSentError;
			value.state = unsent ? 'not-sent' : 'uncertain';
			value.updatedAt = new Date().toISOString();
			value.failedAt ??= value.updatedAt;
			value.lastFailureAt = value.updatedAt;
			value.retryAt = unsent
				? Date.now() + ([2000, 5000, 15000][value.attempts - 1] ?? 60000)
				: 0;
			await saveWakeOutcome(value);
			for (const part of selected) await part.mark(unsent ? 'deferred' : 'failed');
			if (unsent)
				throw new NotificationNotSentError(
					'Automatic notice was not sent; it remains queued.',
					{ cause: error },
				);
			return 'uncertain';
		}
	});
}
