import { randomUUID } from 'node:crypto';

import type { CheckpointPackage, CheckpointState } from './checkpoint-package-model.ts';

import { checkpointConfig, telegramIdentity } from './checkpoint-package-capture.ts';
import { checkpointId, parseCheckpointState } from './checkpoint-package-model.ts';
import {
	checkpointStatePath,
	loadCheckpointPackage,
	newCheckpointPackage,
	saveCheckpointState,
} from './checkpoint-package-store.ts';
import { dailyClaims } from './claims.ts';
import { communicationState } from './communication-state.ts';
import { HIBERNATE_INSTRUCTION, isHibernated } from './hibernation.ts';
import { ackLocalRoom, localAgent } from './local-room-access.ts';
import { locked, optionalText } from './mail-files.ts';
import { recordRead } from './mail-read.ts';
import { TelegramRequestError } from './telegram-api.ts';
import { ackRoom } from './telegram.ts';

function receiptError(kind: 'Invalid' | 'Unknown'): Error {
	return new Error(
		`${kind} checkpoint receipt. No checkpoint cursors advanced. Unseen messages remain unread. Run summon --checkpoint without a receipt to recover the pending batch, read it completely, then pass its returned receipt.`,
	);
}

async function acknowledge(
	name: string,
	state: CheckpointState,
	packet: CheckpointPackage,
	token: string,
): Promise<void> {
	const current = state.current;
	if (!current) throw receiptError('Unknown');
	const page = packet.pages[current.page];
	if (page) {
		if (page.receipt !== token) throw receiptError('Unknown');
		for (const mail of page.completeMail) await recordRead(name, mail);
		state.current = { ...current, page: current.page + 1 };
	} else {
		if (packet.finalReceipt !== token) throw receiptError('Unknown');
		const config = await checkpointConfig();
		if (
			packet.sources.telegram &&
			(!config || telegramIdentity(config) !== packet.sources.telegram.key)
		)
			throw new Error(
				'Telegram source changed during this package. Nothing was acknowledged. Restore the source before retrying the final receipt.',
			);
		if (packet.sources.telegram && config)
			await ackRoom(config, String(packet.sources.telegram.through));
		await ackLocalRoom(String(packet.sources.room.through));
		Object.assign(state.seenHolds, packet.sources.holds);
		state.completedPackage = packet.id;
		delete state.current;
	}
	state.lastAck = token;
	await saveCheckpointState(name, state);
}

function packageOutput(packet: CheckpointPackage, state: CheckpointState, paused: boolean) {
	const index = state.current?.page ?? 0;
	const page = packet.pages[index];
	const addressed = packet.items.filter((item) => item.forMe);
	const laterPages = addressed
		.filter((item) => item.lastPage > index)
		.map((item) => Math.max(index + 1, item.firstPage));
	return {
		...(page?.payload ?? {}),
		paused,
		receipt: page?.receipt ?? packet.finalReceipt,
		changed: !!page,
		more: true,
		package: {
			id: packet.id,
			phase: page ? 'page' : 'final',
			page: page ? index + 1 : packet.pages.length,
			pages: packet.pages.length,
			items: packet.items.length,
			forMe: addressed.length,
			forMeOnPage: page
				? addressed.filter((item) => item.firstPage <= index && item.lastPage >= index)
						.length
				: 0,
			nextForMePage: laterPages.length
				? laterPages.reduce(
						(first, next) => Math.min(first, next),
						Number.POSITIVE_INFINITY,
					) + 1
				: null,
			manifest: 'summon --checkpoint manifest',
			instruction: page
				? 'Read this entire page before passing its receipt. Fragments are UTF-8 pieces of the item JSON; continue in order. The manifest is an index, not a substitute for bodies.'
				: 'Every package page has been acknowledged. Pass this final receipt to commit its frozen source cursors. This is read coverage, never approval, handling, or task completion.',
		},
	};
}

/** Page receipts cover exactly delivered bytes; only the final receipt commits frozen cursors. */
export async function checkpoint(token?: string): Promise<Record<string, unknown>> {
	const name = await localAgent();
	if (await isHibernated(name))
		return {
			hibernated: true,
			changed: false,
			more: false,
			instruction: HIBERNATE_INSTRUCTION,
		};
	await dailyClaims(name);
	if (token !== undefined && !checkpointId.safeParse(token).success)
		throw receiptError('Invalid');
	return locked(`${checkpointStatePath(name)}.lock`, async () => {
		const state = parseCheckpointState(await optionalText(checkpointStatePath(name)));
		let packet = await loadCheckpointPackage(name, state);
		const repeated = token !== undefined && token === state.lastAck;
		const emptyAcknowledgment = token !== undefined && token === state.emptyReceipt;
		const replay = !!packet;
		if (token !== undefined && !repeated) {
			if (emptyAcknowledgment) {
				state.lastAck = token;
				delete state.emptyReceipt;
				await saveCheckpointState(name, state);
			} else {
				if (!packet) throw receiptError('Unknown');
				await acknowledge(name, state, packet, token);
				if (!state.current) packet = undefined;
			}
		}
		try {
			packet ??= await newCheckpointPackage(name, state);
		} catch (error: unknown) {
			// A final receipt is durable before we refresh the next snapshot. Report that
			// acceptance even when Telegram polling fails; never call later arrivals quiet.
			if (
				!(error instanceof TelegramRequestError) ||
				token === undefined ||
				state.lastAck !== token
			)
				throw error;
			return {
				paused: (await communicationState()).paused,
				receipt: token,
				acknowledgedReceipt: token,
				changed: false,
				more: true,
				nextReadError: error.reason,
				warning:
					'The previous receipt was acknowledged. Reading the next package failed; later arrivals remain unread. Run summon --checkpoint without a receipt to retry reading.',
			};
		}
		const paused = (await communicationState()).paused;
		if (!packet) {
			state.emptyReceipt ??= randomUUID();
			await saveCheckpointState(name, state);
			return { paused, receipt: state.emptyReceipt, changed: false, more: false };
		}
		return {
			...packageOutput(packet, state, paused),
			...(repeated
				? {
						warning:
							'Receipt already acknowledged; read this batch, then pass its returned receipt. Its more describes the original package, not the current backlog; later arrivals are read after acknowledgement.',
					}
				: replay && (token === undefined || emptyAcknowledgment)
					? {
							warning:
								'This batch was already issued and is being replayed, not newly read. Read it completely and pass its receipt. Its more describes the original package, not the current backlog; later arrivals are read after acknowledgement.',
						}
					: {}),
		};
	});
}

export async function checkpointManifest(cursor = '0'): Promise<Record<string, unknown>> {
	const name = await localAgent();
	if (!/^\d+$/.test(cursor) || !Number.isSafeInteger(Number(cursor)))
		throw new Error('Invalid manifest cursor.');
	return locked(`${checkpointStatePath(name)}.lock`, async () => {
		const state = parseCheckpointState(await optionalText(checkpointStatePath(name)));
		const packet = await loadCheckpointPackage(name, state);
		if (!packet)
			return {
				items: [],
				next: null,
				instruction: 'No active package. Run summon --checkpoint.',
			};
		const start = Number(cursor);
		if (start > packet.items.length)
			throw new Error('Manifest cursor exceeds package inventory.');
		const items = packet.items.slice(start, start + 20);
		return {
			id: packet.id,
			createdAt: packet.createdAt,
			pages: packet.pages.length,
			sources: {
				room: packet.sources.room,
				telegram: packet.sources.telegram,
				holds: Object.keys(packet.sources.holds).length,
			},
			items,
			next: start + items.length < packet.items.length ? String(start + items.length) : null,
			instruction:
				'Zero-based page ranges. SHA-256 and bytes identify canonical JSON presentation before same-page mirror omission; restore bodyInRoom from that exact room event. Index only: read every page; receipts do not approve or complete work.',
		};
	});
}
