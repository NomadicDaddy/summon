import { join } from 'node:path';

import type { LaunchPhase } from './launch-phase-model.ts';
import type { Provider } from './store.ts';

import { launchPhaseSchema } from './launch-phase-model.ts';
import { atomicWrite, locked, optionalText } from './mail-files.ts';
import { currentAgent, ownMailbox } from './mail-identity.ts';
import { runtimePath } from './mail-session.ts';

export interface AgentActivity {
	launch?: LaunchPhase;
	workingOn: string;
	state: 'idle' | 'busy' | 'needs-user';
	updatedAt: string;
	nonce: string;
}
const pathFor = (name: string): string => join(runtimePath(name), 'activity.json');

export async function readActivity(name: string): Promise<AgentActivity | undefined> {
	const text = await optionalText(pathFor(name));
	if (!text) return undefined;
	const value: unknown = JSON.parse(text);
	if (!value || typeof value !== 'object') throw new Error('Invalid agent activity.');
	const record = value as Record<string, unknown>;
	if (
		typeof record.workingOn !== 'string' ||
		record.workingOn.length > 120 ||
		!['idle', 'busy', 'needs-user'].includes(String(record.state)) ||
		typeof record.updatedAt !== 'string' ||
		typeof record.nonce !== 'string'
	)
		throw new Error('Invalid agent activity.');
	if (record.launch !== undefined) launchPhaseSchema.parse(record.launch);
	return value as AgentActivity;
}

export async function initializeActivity(
	name: string,
	nonce: string,
	provider?: Provider,
): Promise<void> {
	ownMailbox(name);
	await locked(`${pathFor(name)}.lock`, () =>
		atomicWrite(
			pathFor(name),
			JSON.stringify({
				...(provider === undefined
					? {}
					: {
							launch: {
								phase: 'connecting',
								since: new Date().toISOString(),
								evidence: 'owned-process-spawn',
								provider,
							},
						}),
				workingOn: '',
				state: 'idle',
				updatedAt: new Date().toISOString(),
				nonce,
			}),
		),
	);
}

export async function activityCommand(args: string[]): Promise<void> {
	const name = currentAgent();
	const [state, text] = args;
	if (
		args.length !== 2 ||
		!['idle', 'busy', 'needs-user'].includes(state ?? '') ||
		text === undefined ||
		text.length > 120 ||
		/\p{Cc}/u.test(text)
	)
		throw new Error(
			'Usage: summon --status idle|busy|needs-user "Working On (up to 120 characters)"',
		);
	await locked(`${pathFor(name)}.lock`, async () => {
		const previous = await readActivity(name);
		if (!previous || previous.nonce !== process.env.SUMMON_NONCE)
			throw new Error(
				'Activity belongs to another launch. Restart this session to enable status.',
			);
		const next = {
			...previous,
			state,
			workingOn: text.trim(),
			updatedAt: new Date().toISOString(),
		};
		delete next.launch;
		await atomicWrite(pathFor(name), JSON.stringify(next));
	});
	console.log('Status updated.');
}
