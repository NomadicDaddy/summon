/** Full presentation of the delivered payload. No filtering, truncation or receipt advancement. */
export function checkpointText(value: Record<string, unknown>): string {
	const packet = value.package;
	const phase =
		packet && typeof packet === 'object'
			? (packet as Record<string, unknown>).phase
			: undefined;
	const heading =
		phase === 'page'
			? 'CHECKPOINT PAGE'
			: phase === 'final'
				? 'CHECKPOINT FINAL RECEIPT'
				: value.hibernated === true
					? 'CHECKPOINT HIBERNATED'
					: value.changed === false && value.more === false
						? 'CHECKPOINT QUIET'
						: 'CHECKPOINT VIEW';
	const lines = [heading];
	const render = (item: unknown, path: string): void => {
		if (typeof item === 'string') {
			// Length and path distinguish a body containing apparent headings from real metadata.
			const visible = Array.from(item)
				.map((character) => {
					const code = character.charCodeAt(0);
					return (code < 32 && character !== '\n' && character !== '\t') ||
						(code >= 127 && code <= 159)
						? `\\u${code.toString(16).padStart(4, '0')}`
						: character;
				})
				.join('');
			lines.push(
				`${path} (${Buffer.byteLength(item)} UTF-8 bytes; terminal controls escaped):`,
				visible,
				`END ${path}`,
			);
		} else if (Array.isArray(item)) {
			lines.push(`${path}: ${item.length} item(s)`);
			item.forEach((child, index) => render(child, `${path}[${index}]`));
		} else if (item !== null && typeof item === 'object') {
			const entries = Object.entries(item);
			if (!entries.length) lines.push(`${path}: {}`);
			for (const [key, child] of entries) render(child, path ? `${path}.${key}` : key);
		} else lines.push(`${path}: ${JSON.stringify(item)}`);
	};
	for (const [key, item] of Object.entries(value)) render(item, key);
	lines.push(
		'END CHECKPOINT VIEW — read every body and fragment before explicitly passing its receipt.',
	);
	return lines.join('\n');
}
