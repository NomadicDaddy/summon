import { lstat, mkdir, realpath } from 'node:fs/promises';
import { basename, join, resolve } from 'node:path';

import { missing } from './mail-files.ts';
import { operatorOnly } from './mail-identity.ts';
import { storageRoot } from './store.ts';

/** Select before initialization: opening a test team must not rewrite the default registry. */
export async function selectTeamStorage(args: string[]): Promise<void> {
	operatorOnly();
	if (args.length > 1) throw new Error('Usage: summon --team [team-name]');
	const base = resolve(process.env.SUMMON_TEAMS_HOME ?? storageRoot());
	if (args.length === 0) {
		process.env.SUMMON_TEAMS_HOME = base;
		return;
	}
	const name = args[0]?.toLowerCase() ?? '';
	if (!/^[a-z0-9][a-z0-9_-]{0,63}$/.test(name))
		throw new Error(
			'Team names require 1–64 letters, digits, underscores or hyphens, starting with a letter or digit.',
		);
	await mkdir(base, { recursive: true, mode: 0o700 });
	const directory = `team-${name}`;
	const target = join(base, directory);
	const entry = await lstat(target).catch((error: unknown) => {
		if (missing(error)) return undefined;
		throw error;
	});
	if (entry && (!entry.isDirectory() || entry.isSymbolicLink()))
		throw new Error('A named team must be a real directory, not a file or directory link.');
	await mkdir(target, { recursive: true, mode: 0o700 });
	const canonical = await realpath(target);
	const expected = join(await realpath(base), directory);
	if (
		canonical.toLowerCase() !== expected.toLowerCase() ||
		basename(canonical).toLowerCase() !== directory
	)
		throw new Error('Named team directory resolves outside its selected storage.');
	process.env.SUMMON_TEAMS_HOME = base;
	process.env.SUMMON_HOME = target;
}
