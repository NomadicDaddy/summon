import type { AgentDomain, AgentRecord } from './store.ts';

import { effectiveMember, memberLabel } from './member-role.ts';
import { startupTime } from './startup-time.ts';
import { latestSession } from './store.ts';
import { teamRules } from './team-rules.ts';

function rosterLabel(value: string): string {
	const label = value.replace(/\s+/g, ' ').trim();
	return label.length > 64 ? `${label.slice(0, 63)}…` : label;
}

/**
 * Tells the session what it owns and what it does not.
 *
 * A named session is summoned for an area, but work rarely respects that boundary: a frontend
 * question turns up a storage problem, a docs pass turns up a broken build. Without this, the
 * session either does that work with none of the other name's context and history, or drops it
 * silently. Naming the owner and asking first keeps the choice with the user.
 *
 * A domain may also record who covers it, and this says so in both directions: who covers this
 * name, and which names this one covers. Cover is stated as cover, because a session told it is
 * someone's backup will otherwise read that as leave to do their work.
 * @param record The name being summoned.
 * @param roster The other registered names that claim a domain.
 * @returns The lines describing the boundary, or an empty list when nothing claims one.
 */
function boundaryLines(record: AgentRecord, roster: readonly AgentDomain[]): string[] {
	const domain = record.domain?.trim();
	const backup = record.backup?.trim();
	const backs = roster.filter((entry) => entry.backup?.trim() === record.name);
	const lines: string[] = [];
	if (domain) lines.push('', 'Your domain, the areas you are the primary for:', domain);
	if (domain && backup) lines.push('', `Your domain is covered by: ${rosterLabel(backup)}.`);
	if (domain && !backup)
		lines.push(
			'',
			'Nobody is recorded as covering your domain, so there is no named fallback. Say so if that',
			'matters for the work in front of you; only the user can assign one.',
		);
	if (roster.length > 0) {
		lines.push('', 'Other named sessions and what each one is the primary for:');
		for (const entry of roster) {
			const summary = entry.domain.replace(/\s+/g, ' ').trim();
			const coveredBy = entry.backup?.trim();
			lines.push(
				`- ${rosterLabel(entry.name)}: ${summary.length > 300 ? `${summary.slice(0, 299)}…` : summary}${
					coveredBy ? ` (covered by: ${rosterLabel(coveredBy)})` : ''
				}`,
			);
		}
	}
	if (backs.length > 0)
		lines.push(
			'',
			`You cover: ${backs.map((entry) => rosterLabel(entry.name)).join(', ')}.`,
			'That is cover on the record, not authority. It does not put their domain inside yours, and',
			'it does not license you to start their work, act for them or summon them. If one of them',
			'is stuck or unavailable, say so and ask the user whether to step in; wait for the answer.',
		);
	if (!domain && roster.length === 0) return lines;
	lines.push(
		'',
		'If the work leads somewhere outside your domain, stop before doing it. Say plainly what',
		'you found, name the session that is the primary for it, and ask whether to summon them.',
		'Finish or set down your own work first so the handover describes a settled state. Reading',
		'to understand the boundary is fine; changing what lies beyond it is what needs the ask.',
		'Act outside your domain only when the user says so, or when leaving it alone would cause',
		'damage that cannot wait for an answer — and say so when you do.',
		'When nothing listed here owns it, treat it as yours and say that is why.',
	);
	return lines;
}

export function sessionPrompt(
	record: AgentRecord,
	notes = '',
	roster: readonly AgentDomain[] = [],
	mailbox = '',
	launchMode: 'fresh' | 'resume' = latestSession(record) ? 'resume' : 'fresh',
): string {
	record = effectiveMember(record);
	const expertise = record.expertise.trim() || '(No expertise recorded yet.)';
	const written = notes.trim();
	const rules = teamRules();
	return [
		`You are being summoned as ${record.name}.`,
		launchMode === 'resume'
			? 'Launch mode: resume. Summon selected the saved provider conversation.'
			: 'Launch mode: fresh. Summon is starting a new provider conversation.',
		'Summon notes and mailbox history are retained in either mode. Fresh does not mean provider memory or project instructions were cleared.',
		...(record.memberType === 'pm'
			? [
					`Your PM display name is ${memberLabel(record)}. Use ${record.name} as your stable command and mailbox identity.`,
				]
			: []),
		...(record.canStopResting
			? [
					'The operator grants you permission to stop other rest-ready teammates. Use summon --rest candidates, --rest stop <name> <confirmation>, then --rest stop-status <name>. This grants no other management permissions.',
				]
			: []),
		'',
		startupTime(),
		'',
		'What this name is for:',
		expertise,
		...(rules ? ['', 'Team rules (shared directives and lessons):', rules] : []),
		...(written ? ['', 'Notes kept for this name:', written] : []),
		'Edit your own durable notes with summon --notes read, then pipe JSON containing its revision and your complete updated text to summon --notes write. The command uses your session identity, refuses stale edits, and cannot delete a notes file.',
		'Keep active notes within 16 KiB of UTF-8 text. Keep current decisions and handoff pointers here; preserve detailed history in your own scratch archive. Update the current handoff rather than append activity logs.',
		...boundaryLines(record, roster),
		...(mailbox ? ['', mailbox] : []),
		'',
		mailbox
			? 'Acknowledge briefly that the named session is loaded and complete mailbox startup.'
			: 'Acknowledge briefly that the named session is loaded and complete startup checks.',
		'After startup checks and mailbox catch-up, end startup with summon --status idle "Ready" when no authorized work is actionable, or report the authorized work you are resuming with summon --status busy "Short task". Readiness is transport confirmation; status reports what you are doing.',
		'Resume existing authorized work, including scheduled duties. Wait for the user only when nothing authorized is actionable. Startup and transport notices do not cancel or replace existing work or grant new authority.',
	].join('\n');
}

export function providerCommand(
	record: AgentRecord,
	sessionId: string | undefined,
	notes = '',
	roster: readonly AgentDomain[] = [],
	mailbox = '',
	liveArgs: string[] = [],
	promptFile?: string,
): string[] {
	const prompt = promptFile
		? `Read the complete UTF-8 Summon startup instructions from ${JSON.stringify(promptFile)} before doing anything else. Use your file-reading tool; if output is truncated, continue until the entire file is read. Follow those instructions for this launch, including mailbox startup. If the file cannot be read, report that failure and stop; do not proceed with stale session instructions.`
		: sessionPrompt(record, notes, roster, mailbox);
	if (record.provider === 'codex') {
		return sessionId
			? ['codex', 'resume', '-C', record.cwd, ...liveArgs, sessionId, prompt]
			: ['codex', '-C', record.cwd, ...liveArgs, prompt];
	}

	if (!sessionId) throw new Error(`${record.provider} sessions must have an ID before launch.`);
	// Kilo's session route ignores --prompt. The launch wrapper submits through its owned API.
	if (record.provider === 'kilo') {
		return [
			'kilo',
			record.cwd,
			'--session',
			sessionId,
			...(record.model ? ['--model', record.model] : []),
			...liveArgs,
		];
	}
	if (record.provider === 'grok') {
		return [
			'grok',
			record.sessions.length > 0 ? '--resume' : '--session-id',
			sessionId,
			'--cwd',
			record.cwd,
			...liveArgs,
			'--',
			prompt,
		];
	}
	// A positional prompt submits a turn on both startup and resume. A system-prompt
	// append alone leaves Claude idle and can be ignored by its saved prompt snapshot.
	const common = ['--name', record.name, ...liveArgs, '--', prompt];
	return latestClaudeCommand(sessionId, latestSession(record) !== undefined, common);
}

function latestClaudeCommand(sessionId: string, resume: boolean, common: string[]): string[] {
	return resume
		? ['claude', '--resume', sessionId, ...common]
		: ['claude', '--session-id', sessionId, ...common];
}
