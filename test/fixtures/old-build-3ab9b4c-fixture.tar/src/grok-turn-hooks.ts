import { createHash } from 'node:crypto';
import { mkdir, unlink, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';

import { initializeGrokTurn } from './grok-turn-state.ts';
import { optionalText } from './mail-files.ts';
import { storageRoot } from './store.ts';

export function grokTurnHooks(name: string, nonce: string, thread: string) {
	const script = resolve(import.meta.dir, 'grok-turn-hook.ts');
	const single = (value: string): string => `'${value.replaceAll("'", "'\\''")}'`;
	const windows = `& '${process.execPath.replaceAll("'", "''")}' '${script.replaceAll("'", "''")}'; exit $LASTEXITCODE`;
	const command =
		process.platform === 'win32'
			? `pwsh -NoProfile -NonInteractive -EncodedCommand ${Buffer.from(windows, 'utf16le').toString('base64')}`
			: `${single(process.execPath)} ${single(script)}`;
	const hook = {
		type: 'command',
		command,
		timeout: 5,
		env: {
			SUMMON_HOME: resolve(storageRoot()),
			SUMMON_AGENT: name,
			SUMMON_NONCE: nonce,
			SUMMON_GROK_SESSION: thread,
		},
	};
	return {
		hooks: {
			UserPromptSubmit: [{ hooks: [hook] }],
			PreToolUse: [{ hooks: [hook] }],
			Notification: [{ matcher: '^idle_prompt$', hooks: [hook] }],
			PreCompact: [{ hooks: [hook] }],
			PostCompact: [{ hooks: [hook] }],
		},
	};
}

/** An exact launch owns its unique file. Existing user hooks are never overwritten or trusted. */
export async function installGrokTurnHooks(
	name: string,
	nonce: string,
	thread: string,
	home = process.env.GROK_HOME ?? join(homedir(), '.grok'),
): Promise<() => Promise<void>> {
	await initializeGrokTurn(name, nonce, thread);
	const id = createHash('sha256')
		.update(JSON.stringify([resolve(storageRoot()), name, nonce]))
		.digest('hex');
	const directory = join(home, 'hooks');
	const path = join(directory, `summon-turn-${id}.json`);
	const body = `${JSON.stringify(grokTurnHooks(name, nonce, thread))}\n`;
	await mkdir(directory, { recursive: true });
	await writeFile(path, body, { flag: 'wx', mode: 0o600 });
	return async () => {
		// A replacement or human edit belongs to its author; do not remove it.
		if ((await optionalText(path)) === body) await unlink(path);
	};
}
