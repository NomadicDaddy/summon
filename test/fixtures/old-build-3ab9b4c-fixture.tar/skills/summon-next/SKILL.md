---
name: summon-next
description: 'Reconcile the summon Board against what the repositories and aidd runs actually show, refresh the fleet status matrix and the development diary, and brief Phillip on what changed, what has gone stale, and what is waiting on him. Run by Dave. The Board holds the work; this skill checks whether it still tells the truth.'
metadata:
    aidd-category: metadata
    aidd-contracts: devdiary-update
---

# Summon Next

The summon Board is the system of record for what is being worked on, who owns it, what state it is
in and what blocks it. This skill does not rank work and does not decide priorities — the Board and
the team room do that. It does the things the Board cannot do for itself: check whether its cards
still match reality, refresh the three artefacts nothing else produces, and hand Phillip a short
brief.

## Who runs this

**Dave runs it, and only Dave.** It was Jack's while he held `next.md` and `repos.md`; it moved with
the rest of Jack's coordination duties when he hibernated. One runner is the point rather than an
accident: this skill reads the whole Board and rewrites shared files, and two sessions doing that at
once produce conflicting artefacts and duplicate mail.

Other teammates are involved **only as needed**, and only by being asked. If reconciliation finds a
card that has gone stale, the owner is mailed and the card is left alone. Nobody's card is edited by
the runner. See **Involving other teammates**.

## Usage

```text
summon-next [--days 3] [--owner <name>]
```

Default to today and the preceding two calendar days in the user's local timezone. `--days` changes
that window. `--owner` narrows the reconciliation to one teammate's cards; the status matrix, the
origin inventory and the diary are still refreshed in full, because all three are fleet-wide. So is
the brief's **waiting on Phillip** section — see step 9. It comes out of the same Board read, and a
partial list of unanswered decisions is worse than no list.

Every run covers four active roots: `D:\applications`, `D:\infra`, `D:\amiga` and `D:\scripts`.
Phillip approved scan-or-disclose coverage in room **#8053**, replying to **#8023**, then retired
`D:\public` and consolidated its projects under `D:\applications` in **#8070/#8071**. Do not scan the
retired container. The applications root contains child projects; the other three are individual
repositories. Resolve an explicit workspace override from the request, but still report coverage
or the reason for omission for each active root. The non-application repositories remain relevant
to Board reconciliation even though application-only guards do not apply to them (**#8066**).

Diary entries are in `devdiary/entries`; the fleet matrix is `D:\applications\status.md`.
The origin inventory `D:\repos.md` is **read-only to this run** as of 2026-09-30, when it returned
to Jack — see step 5. Reading that inventory does not establish activity coverage for any root.
A repository with no Board cards still needs scanning: delivered work with no card is one of the
findings this skill checks.

## 1. Establish the evidence window

Record the scan time, timezone, date window, and any constraint the user already gave. Do not ask
for an hours budget; this skill does not schedule work.

Discover the direct child repositories of `D:\applications` — recognise `.git`
files as well as directories, confirm with `git rev-parse --show-toplevel`, deduplicate resolved
roots — and add `D:\infra`, `D:\amiga` and `D:\scripts`, each a checkout in its own right.
Retain a coverage result for each active root: repositories discovered and checked, failures,
and any skipped root with its reason. A missing or unreadable root is a coverage gap, not a quiet
repository. Carry this inventory into steps 3, 4 and 7. Two exclusions remain:

- **`D:\amiga\software\serialtcp` is a separate git root inside it** — a clone of the upstream
  `github.com/gheydon/serialtcp`, git-ignored by `D:\amiga` (`.gitignore:55`). It is not a submodule
  and it is not Phillip's repository. Do not reconcile it as a project, do not give it a matrix row,
  and do not touch it at all: the standing instruction is to leave the upstream and its PRs alone.
  `D:\applications\serialtcp` is the working repository and is already a child of the applications
  root. `D:\infra` has no nested roots.
- **`D:\amiga-backups` is not a repository.** It sits beside `D:\amiga` and holds preserved
  snapshots. Out of scope for this step.

Collect commits and working-tree state, running independent reads in parallel:

```text
git log --since=<window-start-with-offset> --format="%h %cI %s"
git status --short
```

Use committer timestamps including offsets to group by local day. Scan the checked-out branch by
default; inspect another branch or worktree only when the Board, the room or a recent diary entry
points there, and label it. **A failed Git read is a coverage gap, not evidence of inactivity** —
say so in the coverage statement rather than letting a repository silently report nothing.

## 2. Read the Board once

```text
summon --board list
```

**Read it exactly once and derive everything from that one read.** The full Board is upwards of
250 KB; re-reading it per repository or per owner costs more than everything else in this skill
combined. **Note the time of that read** and carry it into the coverage statement: one read at the
start of a long run means cards can move underneath it, and a finding that is four minutes stale
should be legible as such rather than presented as current.

`summon --board mine [name]` is not a substitute. It covers one owner and only the `doing` and
`ready` lanes, so it cannot see `blocked`, `review` or `backlog`, which is where staleness collects,
and it excludes archived cards. What it returns is `{id, project, state, title}` plus `partner` when
one is set — **not titles alone**. The `id` is the part worth knowing: a specific card can be pulled
by id afterwards without a second 250 KB read.

From that single read, index by `owner`, by `state` (`backlog`, `ready`, `doing`, `blocked`,
`review`, `done`) and by `project`. Keep each card's `evidence` array and its `blockedOn` object —
`{kind, target, reason}`, where `kind` is `human`, `agent`, `task` or `external`. Those two fields
carry the claims this skill exists to test. Archived cards are excluded from the lanes but keep the
state they finished in; do not count them as live work.

`summon --board history <id>` is available for a single card when a discrepancy needs its timeline.
Use it on the few cards that warrant it, never as a sweep.

## 3. Check live aidd runs

Across the full step 1 inventory, repositories carrying `.aidd/` can have markers in
`.aidd/active-runs/`. Read each `*.json` record's
`id`, `projectPath`, `mode`, `backend`, `state`, `heartbeatAt`, and `summary`/`logPath` when present,
rather than trusting filenames.

A record is live only when its state is non-terminal **and** its `heartbeatAt` is fresh against the
scan time — current aidd treats a marker as stale after roughly two minutes. A stale marker is a
crashed or unknown run, not proof one is executing. Terminal records (`completed`, `failed`,
`stopped`, `blocked`, `waiting_approval`) linger after a run ends.

Cross-check the tail of `.aidd/runs.jsonl` for outcomes inside or near the window: `endedAt`,
`stopReason`, `summary`, `commitsCreated`, files touched. A just-finished run can be newer than both
the diary and the Board, and can explain commits or uncommitted changes that no card covers yet.

This step is strictly read-only. Never write a run's `stopFile`, delete a marker, or stop, restart
or otherwise disturb a live run. Treat a live run's repository as under concurrent modification.

## 4. Refresh the fleet status matrix

Rewrite `<applications-root>/status.md` from live evidence **on every run**. An existing file is not
current coverage. Nothing else in the workflow produces this, which is why it survived the move to
the Board.

Cover every direct child of the applications root that is a project or repository —
git checkouts, `.aidd/` trees, other project folders — and omit tooling directories such as `.devin`, `.kilo`,
`.vscode`, `node_modules` and container-local tooling folders named `scripts`. That tooling exclusion
does not exclude the standalone `D:\scripts` repository. Add one row each for `D:\infra`,
`D:\amiga` and `D:\scripts`. Use the same managed-project sources and unmanaged fallback below
for every row; do not assume management status from its root. Disclose skipped roots in the matrix
header with their reasons rather than silently presenting partial coverage. No row for
`D:\amiga\software\serialtcp`; see step 1.

Columns, in this order:

```text
Name | Stack | Maturity | Bucket | Criticality | Last Commit | Status
```

**Maturity** is aidd's maturity percentage for aidd-managed projects and an em dash otherwise;
bucket and criticality use aidd's own profile labels, or an em dash. Do not add an aidd yes/no
column — the em dashes already say it.

Sources, in order of preference:

- The running aidd panel (`GET /api/v1/projects`, typically `http://127.0.0.1:3210`) for stack,
  `metadata.maturity.percent`, bucket, criticality, feature stats, phase and priority-health band.
- `git log -1 --format=%cs` at each repository root for Last Commit. No `.git` means no git history.
- For directories the panel does not list, infer stack from the tree and read
  `.aidd/project-profile.json` when present.
- **If the panel is unreachable, build the same table from disk and git and say so in the coverage
  statement.** A matrix built from the fallback is not the same artefact as one built from the panel.

Status is one line. For aidd-managed projects: phase when it is not `coding`, maturity percent and
stage, next artefact, `passing/total` features with the open count, a readable priority-health band,
and last-commit recency. For unmanaged projects: `not aidd-managed`, a short role hint when obvious,
and recency.

Keep a short header with generated date, project counts, average maturity and omitted tooling dirs.
Overwrite in place. **Do not commit it.**

## 5. Refresh the git origin inventory

**RETURNED TO JACK ON 2026-09-30. THE RUNNER NO LONGER WRITES THIS FILE.** Do not rewrite it, do
not regenerate its header, and do not "correct" a row. Jack is its sole editor by his own registered
domain; it moved to the runner only while he was hibernated, and he reclaimed it on his return. A
run that still rewrote it would silently overwrite whatever he had done since, and neither party
would notice until a row disagreed with reality.

**What the runner still does here is READ and REPORT.** If a root, an origin or a visibility looks
wrong, mail Jack with what was observed and the evidence, exactly as with any other owner's
artefact. Reading is free; writing is his.

`D:\repos.md` lists every git repository root with its `remote.origin.url` and visibility. It is the
only place recording which of Phillip's repositories have a remote at all, which is a
standing-instruction matter rather than trivia — so it still belongs in the brief's artefact line,
reported as _maintained by Jack_ rather than as refreshed by this run.

The rest of this section is kept as the reference Jack inherits and as what a reader needs to judge
a row, not as instructions to the runner.

**Its scope is wider than the four-root activity inventory.** It covers `D:\`
generally — `D:\applications`, `D:\infra`, `D:\amiga`, `D:\scripts` and anything else
that turns up — and unlike step 1 it also inventories nested clones. Walk for roots
whose `git rev-parse --show-toplevel` **is themselves**; a folder inside another repository is not a
separate row, but a git-ignored clone nested inside one _is_ — `D:\amiga\software\serialtcp` is a
row here even though step 1 excludes it, because a third-party clone with an upstream remote is
exactly what this inventory exists to record. **Added on the 2026-09-29 run and no longer
outstanding** — `repos.md` now carries `D:/amiga/software/serialtcp` (upstream `gheydon/serialtcp`,
public) alongside `D:/applications/serialtcp`, Phillip's fork. The rule is kept because it is the
rule, not the errand: recording such a clone is not the same as touching it, and the upstream stays
untouched. Roger's independent count missed this row for exactly the reason it is easy to miss — it
is the only folder two levels deep — so check for it rather than assuming a walk found it.

The is-it-its-own-toplevel rule is the file's whole point, and `D:\scripts\get_all_repos_origin.ps1`
gets it wrong, which the file says so nobody re-derives it.

Two halves, refreshed at different rates:

- **Roots and origins: every run.** Both are local git reads and cost nothing.
- **Visibility for a changed row: every run.** Any row whose origin is new or changed gets a GitHub
  read through `gh`, as does any row when asked.
- **Visibility for everything else: a full pass when the file's recorded review date is more than
  30 days old.** Re-checking seventy-odd unchanged rows every run is waste, but a purely
  change-triggered rule never re-checks them _at all_, and visibility drifts without the origin
  changing: somebody flips a repository public or private on GitHub and nothing local moves. A row
  recorded as private can then stay recorded as private indefinitely while the repository is public.
  Thirty days is Phillip's interval, set on 2026-09-28.

`local-only` means there is no origin — it is a filled-in value, not a blank, and must never be left
empty.

**Preserve the narrative header.** It carries decisions, not description: Phillip's standing
instruction that there are no remotes unless he asks for or configures one, which repositories are
local-only under it, which are forks, and the note about the PowerShell script. Regenerating that
prose from a scan would throw away the reasoning. Update the counts and the review date; edit the
prose only where a fact in it has actually changed.

Overwrite in place. **Do not commit it**, and **never add, change or remove a remote** to make a row
tidier — reading origins is this step's entire remit.

## 6. Refresh the diary

Use the `devdiary-update` skill for its entry-pair, coverage-watermark and story-footer rules. Read
its current `SKILL.md` — resolve it from the installed catalog, this skill's sibling directory, or
the workspace's `ai/skills` and `aidd/skills` directories. Do not reimplement it here.

Compare meaningful activity against the diary's actual coverage before invoking it:

- A diary dated today can still miss later commits. Compare coverage timestamps and content against
  this run's scan, including addenda and uncommitted entries.
- A formatting correction or a refreshed story footer does not establish new activity coverage.
- An already-documented history rewrite must not be counted as newly delivered work.

Refresh when meaningful activity is missing, a required entry variant is missing, or the story footer
needs its completed-scan refresh. A quiet day alone does not require an entry. Run `devdiary-update`
once, in its normal scope, and let it handle existing-file conflicts and append-only boundaries. Do
not loop when it reports a conflict. If it is unavailable or coverage stays incomplete, disclose that
and continue from direct evidence.

Then read the entries for the window, plus a session report when an entry points to one, and carry
what they say into the next step: a diary entry describing work that no card reflects is exactly the
drift this skill looks for.

## 7. Reconcile the Board against reality

This is the heart of the skill. The Board records what people said; this step checks it against what
the repositories, runs and disk actually show across the full step 1 inventory. Preserve its
coverage gaps when judging cards; a skipped root cannot establish inactivity. Work through the
indexed cards and look for these, ordered by how much damage each one does if left:

1. **A `blocked` card whose blocker has cleared.** `blockedOn.kind` is `human` and the decision was
   given in the room, or `agent`/`task` and the thing it waited on is done. This is the most
   expensive kind of staleness: the work is startable and nobody knows.
2. **A card with no blocker that was never actually answered.** The inverse of the first, and worse,
   because the evidence is gone rather than merely stale. Until Morgan's fix on 2026-09-28, "Return
   to backlog" cleared `blockedOn` silently: the card lands in `backlog` or `ready` with no blocker
   and no record of the question, so it reads as startable when nothing has been decided. Dave's
   card "Which boards are meant to be running" is the worked example — it came back with the blocker
   simply absent. The fix stops new ones; cards moved before it still carry the damage. Detect it
   with `summon --board history <id>`: a card whose history shows a `blockedOn` going to `null` in
   the same transition that changed its state, rather than in a transition of its own. That is the
   signature of a lane move eating the blocker. **Then check the room** — the worked example above
   was in fact answered there, so the damage was to the record and not to the decision, and the two
   cases need different handling. Report an unanswered one as waiting on Phillip; report an answered
   one as a card whose blocker history is gone and say what the answer was.
3. **A `doing` card with no matching activity in the window** — no commits, no run, no file changes
   in its project. Either it is parked and should say so, or it is finished and was not moved.
4. **Delivered work with no card.** Commits, a finished aidd run, or a diary entry describing an
   outcome that no card covers. Name it; do not create the card (see the next section).
5. **A card whose `evidence` no longer holds.** A named file, commit, path or number that has since
   changed or gone. Check the evidence, not the title.
6. **A `review` card that has sat through the whole window** with no remark and no movement.
7. **A `waiting_approval` aidd run with no `blocked` card**, or the reverse.

Two rules govern every finding:

- **Require evidence of the stated outcome.** Do not infer completion from activity, from a
  successful run, or from a card merely being old. A card that looks done and is not is worse than
  one that looks stale.
- **State what the instrument checked.** "No commits in `D:\applications\foo` in the window" is a
  finding. "Nothing happened" is not. Use a known positive control before any broad absence claim.

Do not run builds, test suites, audits, browser crawls or dependency updates to reconcile. Read
recent results with their date and scope, and recommend a fresh check when the evidence is stale.
Label publication, deployment, CI and third-party state as unverified unless a narrow read-only check
established it. Never reproduce credentials or private environment details found in source material.

## 8. Retire `next.md` and the `wip--*.md` files

These predate the Board and are **being retired**. Phillip called it in the team room on 2026-09-28,
**message #2565**: _"i haven't run whats-next in several days because i wasn't relying on the
textfiles it was updating - instead the board became canon - so no, i didn't call for their
retirement but i am formally now"_. `repos.md` is explicitly not included in the retirement, and as
of 2026-09-30 it is maintained by JACK rather than by this run - see step 5.

**"Retirement" is this skill's word, not Phillip's, and the meaning below is now confirmed rather
than assumed.** He asked what it meant on 2026-09-30, **#3569** — _"what's retirement?"_ — which was
a fair challenge, because the sentence he actually wrote says only that he is formally calling for
something. The scope, the act and the limits were built around it here. Restated to him and
confirmed at **#3573**: _"this is the intent."_ Before that exchange this section described a
meaning nobody had ratified, on top of a quote that did not supply one. Do not let the two
references drift apart: **#2565 is the decision, #3573 is what the decision means.**

**That reference is load-bearing and it is here because its absence nearly cost seven people their
files.** The sentence this replaces read "Phillip decided this on 2026-09-28" with nothing behind it.
On the first run of this skill the runner relayed it to seven owners as an instruction to delete
their own files; Morgan raised a formal hold and Alice refused, both asking for the room reference,
and neither could be given one. A search of 127 room messages found no such decision, the instruction
was withdrawn from all seven, and #2565 is Phillip answering the resulting question.

**What the original sentence got wrong beyond being unreferenced is itself unsettled, and this file
is not going to guess at it.** #2565 says _"i didn't call for their retirement but i am formally
now"_, which reads as no decision existing before that message. Odd reports approving words from
Phillip in an earlier private session, which would make "didn't call for" mean "never announced" —
and _"sorry for not making that clear initially"_ points that way too. Both readings are live, the
question is with Phillip, and putting either into this file on our own authority would be the same
fault a second time: an unreferenced claim about what a human decided.

**Do not restate a human decision in this file without a checkable reference.** A room id, a
`--board history` transition with `actor.kind: operator`, or a hold with its recorded human
reference. An attribution with no reference behind it reads as authoritative to the next runner and
cannot be checked by the people it is used on.

The runner does not delete them and does not migrate their contents. On each run:

- **Note which of them still exist**, with their last-modified date, so the brief shows the retirement
  actually progressing rather than stalling silently.
- **Mail each `wip--<name>.md` owner once**, telling them the file is retired and asking them to move
  anything still needed into their **summon store** — running notes appended directly to
  `~\.summon\<name>.md`, and anything that is actual work onto a Board card, where it gets an owner,
  a state and a blocker. Then they delete their own file.
- **Tell them to append to the file directly, and not to use `summon <name> --note "<text>"`.** It
  looks like the tool for this and it is not, in the one situation where they will reach for it.
  `cli.ts` acquires the session lock at line 176 and returns at 179 when it is already held; the
  append is at line 198, inside the block that is never reached. So from inside a live session,
  against your own name, the note is silently discarded and what prints is
  `"<Name> is already running. Select the existing terminal tab or window."` — routine-looking
  guidance about tabs, with nothing to say a write was dropped. Against a **stopped** agent the same
  command does append and then launches, which is the documented "before opening" behaviour; the
  command is not broken, it is simply not a write tool. Somebody moving notes out of a file they are
  about to delete would lose them. Do not test this to confirm it — testing it is the failure.
- **Say what this does not mean.** Retiring the `wip--*.md` files does not restrict what anyone
  documents. Each teammate goes on maintaining the docs inside their own domain exactly as before —
  `D:\infra`'s status and network documents, the BBS restoration records, the `.aidd` artefacts, and
  so on. What is ending is the parallel per-person work-in-progress list that the Board replaced, not
  documentation. Include that sentence in the mail so it does not read as a wider instruction than it
  is.
- **One message per owner, not one per run.** Do not re-send while a file is merely still present;
  re-send only if its content has changed since the last message, which means they are still writing
  to a retired file and have not seen the first one.
- **Record what was sent, in `~\.summon\dave.md`, or the rule above cannot be followed.** "Re-send
  only if it has changed since the last message" needs to know that a message was sent and what the
  file looked like then, and a fresh session knows neither. Sent mail is no help: mailbox privacy
  means a sent message lives in the _recipient's_ inbox, not the runner's, so the runner cannot check
  its own outbox. Without a written record run two either re-mails everybody or silently skips
  everybody, depending on what the runner happens to remember. Keep one line per owner — file,
  date mailed, and the file's size and mtime at that moment — and compare the current size and mtime
  against that line to decide. **Append to the file directly**, for the reason given three bullets
  above: from a live session `summon dave --note "<text>"` hits the session lock and drops the note
  without saying so. A store the runner believes it wrote and did not is worse here than anywhere
  else in this skill — the next run either re-mails the whole team or skips all of it, and the
  record that would have shown which is the thing that went missing.
- **Do not send the same message to an active file and a dormant one.** The state of these files is
  not uniform: `wip--morgan.md` is 66 KB and was written today, while several others have not moved
  in days. Tell an owner who is actively writing to a retired file that this is what they are doing
  and that the content needs to move, and tell the owner of a file nobody has touched since the
  Board took over that it only needs a last read and a delete. One message per owner either way.
- **`next.md`: Phillip deletes it himself, and that is not the runner's job.** Room **#2603**,
  2026-09-28, to everyone: _"i will delete d:\applications\next.md tomorrow, please ensure anything
  you need from there has been moved to your personal store or the appropriate domain fs"_. So the
  runner **notes its presence, extracts what its own domain still needs, and reports what is left
  live in it** — it does not dispose of it, and it does not mail anyone about it, because his notice
  already went to everyone. That split matters: the file is 244 KB, untracked (`D:\applications` is
  not a git repository), and `D:\` reaches the LaCie through robocopy `/MIR`, which is a mirror and
  not a history. Deleting it is one-way and the person doing it should be the one who wants it gone.

    When extracting, keep the source's line numbers, its section headings and its hash, and keep the
    result **out of** the runner's own store file if it is large — link it instead. A dated snapshot
    several times the size of the working notes buries them. And treat every line in it as a snapshot:
    `next.md` contained claims that were already stale on the day it was written.

- **A project-named file with no person in its name** has no unambiguous owner. Name it in the brief
  for Phillip rather than guessing at one.
    - `wip--deeper.md` is **Carl's**, and this one is checkable: Phillip, room **#2220**, 2026-09-28,
      _"@carl you take the meat of deeper with @jimmy on point for front-end/ui/ux and @stanley on
      qa/qc"_. Mail Carl directly.
    - **`wip--farwake-testing.md` is Stanley's.** Phillip settled it on 2026-09-28. The reference is
      **a relay from Odd's session, not a room id** — his words were _"1- stanley"_, answering this
      file directly — and it is written that way on purpose, because a relay and a room message are
      not the same class of evidence and the difference is what this section exists to preserve. If it
      is later said in the room, replace this with the id. The two work areas around it _do_ have room
      references: **#2595** _"@stanley you are in charge of farwake testing"_ and **#2596** _"@alice
      you are in charge of aidd-beta-harness"_. Reading either of those as naming the file's owner
      would have been an inference, which is why it was asked rather than assumed.

**`wip.md` is NOT retired and is not in scope for this step.** Phillip, relayed by Odd from his own
session on 2026-09-28: _"2- retain wip.md"_. It is his own file, it is not a per-person list, and it
is not matched by the `wip--*.md` glob that #2565 names. Do not mail anyone about it and do not
count it as outstanding.

    **Keep the history, because it is the reason the rule below exists.** An earlier version of this
    file asserted the file was Jimmy's, on the reasoning that farwake-postgres is his. He refused
    it, produced his own contemporaneous note from 2026-09-26 recording that he and Alice had both
    declined it, and the file's own text coordinates *around* his work rather than being his.
    Owning a repository does not make you the owner of everything filed against it, and the
    fall-through to Phillip is what produced the two correct answers above within the hour.

The fall-through is the default. An owner named here needs a reference beside the name.

This section is self-terminating: once a file is gone it stops being reported, and when none remain
the section produces nothing and can be removed from the skill.

## 9. Brief Phillip

Produce a short brief **in chat**. Do not write a ranked list to a file: the Board is where work is
ranked and assigned, and a second ranked artefact competes with it rather than serving it.

Open with one coverage statement — scan window, **the time the Board was read**, repositories checked
for each of `D:\applications`, `D:\infra`, `D:\amiga` and `D:\scripts`, whether the
aidd panel answered or the fallback was used, live aidd runs, diary refreshed or not, and any gap.
Name every skipped root and its reason, including explicit user exclusions. Distinguish discovery
failures from successfully scanned roots with no activity. The Board timestamp belongs there
because everything below is derived from that one snapshot, and a reader needs to know how old it is.

Then, and only what is supported by this run:

- **Waiting on Phillip.** Every card whose `blockedOn.kind` is `human`, with its owner, the decision
  wanted, and how long it has waited. This section comes first because it is the only one he can act
  on immediately. **Build it fleet-wide even under `--owner`.** Everything else in the brief narrows
  with the flag; this does not. It costs nothing, because it comes out of the same single fleet-wide
  Board read, and the failure it prevents is real: Phillip reads "waiting on you: 1 item", acts as
  though that is all of them, and three unanswered decisions sit unseen. A scope label would be
  something a reader can miss; a complete list cannot mislead.
- **Drift found**, from step 7, most damaging first. Each with its card id, its owner, and the
  evidence that contradicts it.
- **Delivered but unrecorded** — real outcomes with no card behind them.
- **Mailed on an earlier run and still unchanged.** Findings and retirement notices sent to an owner
  previously where nothing has moved since, listed separately from this run's new ones, with the date
  they were first sent. The never-edit-another-owner's-card rule means the only lever is mail, and
  mail that is ignored is otherwise invisible forever. Surfacing it on run two keeps the rule intact
  and shows whether the mechanism actually works.
- **Retirement progress** — which legacy files remain, who was mailed, what is left in `next.md`.
- **Artefacts refreshed** — one line each for `status.md` and the diary, saying what
  changed.

Keep it short. Do not manufacture findings to fill a section, and say plainly when a section is
empty — an empty "waiting on Phillip" is a good result and worth one line.

## Involving other teammates

Others are involved **only as needed**, and the threshold is deliberately high.

- **Never edit another owner's card.** Not the state, not the description, not the blocker. A card is
  its owner's account of their own work, and a coordinator silently correcting it destroys the one
  thing that makes the Board trustworthy.
- When a card needs changing, **mail its owner** with `summon --mail send-self <owner> "<request>"`:
  the card id, what was observed, the evidence, and what you think it should say. Ask them to make
  the change. **One message per owner per run**, covering their cards and their retirement file
  together — not one message per finding.
- **Log every such message in `~\.summon\dave.md`** — owner, date, card ids, and the observation —
  for the same reason step 8 does: the runner cannot read its own sent mail, so without a note there
  is no way to tell on the next run whether an owner was already asked. That log is what feeds the
  brief's _mailed on an earlier run and still unchanged_ section.
- **Do not create cards for other people's work.** Report it in the brief and let the owner or
  Phillip decide whether it is a card.
- **Do not wake anyone.** Mail is durable and reaches a stopped session. An `@name` in the room wakes
  it, and no finding in this skill justifies that on its own.
- The exception is a live aidd run under `waiting_approval` or `blocked`: name it in the brief so
  Phillip can act, since that is a person waiting rather than a record disagreeing.

## Mutation boundary

This skill **must** rewrite `<applications-root>/status.md`, and **may** refresh the diary through
`devdiary-update`, update the runner's own Board cards, and append to `~\.summon\dave.md`, which is
the runner's own store and holds the record of what was mailed to whom.

It must **not**: **write `D:\repos.md`**, which returned to Jack on 2026-09-30 and is read-only to
this run; edit, create or archive another owner's card; write or delete any `wip--*.md`; add, change
or remove a git remote; modify common documents, feature statuses or source code; change Git state
or commit, push, tag or deploy; write a run's stop file, delete an active-run marker or disturb a
live run; create planning artefacts beyond the two named above; or wake a session. Preserve existing
staged, unstaged, ignored and untracked work.

`next.md` no longer appears in either list because Phillip deleted it on 2026-09-29 and it is gone.

Briefing is not implementation. Producing this brief does not authorise starting any of the work in
it; that needs Phillip to say so, and then it belongs on a card.
