import { readFile } from 'node:fs/promises';
import { homedir, platform } from 'node:os';
import { join } from 'node:path';

import { missing } from '../../../src/mail-files.ts';
import { runtimePath } from '../../../src/mail-session.ts';
import { parseOwner, type ProcessOwner } from '../../../src/process-owner.ts';
import { listAgentSlugs, loadAgent, storageRoot } from '../../../src/store.ts';
import { isSessionHost, program } from './hosts.ts';

interface ProcessInfo {
	pid: number;
	ppid: number;
	name: string;
	args: string[];
}

function splitCommandLine(command: string): string[] {
	const args: string[] = [];
	let current = '';
	let quoted = false;
	for (const char of command) {
		if (char === '"') {
			quoted = !quoted;
			continue;
		}
		if (!quoted && /\s/.test(char)) {
			if (current) args.push(current);
			current = '';
			continue;
		}
		current += char;
	}
	if (current) args.push(current);
	return args;
}

function sessionArg(args: string[], slug: string): boolean {
	const index = args.indexOf('__session');
	return index >= 0 && args[index + 1] === slug;
}

function processes(pids: number[]): Map<number, ProcessInfo> {
	const wanted = [...new Set(pids.filter((pid) => pid > 0))];
	const found = new Map<number, ProcessInfo>();
	if (wanted.length === 0) return found;
	if (platform() === 'win32') {
		const script = `
$ids = @(${wanted.join(',')})
Get-CimInstance Win32_Process | Where-Object { $ids -contains $_.ProcessId } |
  Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress
`;
		const result = Bun.spawnSync({
			cmd: ['pwsh', '-NoProfile', '-Command', script],
			stdout: 'pipe',
			stderr: 'pipe',
		});
		if (result.exitCode !== 0) throw new Error('Could not query Windows processes.');
		const text = result.stdout.toString().trim();
		if (!text) return found;
		const parsed: unknown = JSON.parse(text);
		const rows = Array.isArray(parsed) ? parsed : [parsed];
		for (const row of rows) {
			if (!row || typeof row !== 'object') continue;
			const record = row as Record<string, unknown>;
			const pid = Number(record.ProcessId);
			found.set(pid, {
				pid,
				ppid: Number(record.ParentProcessId),
				name: typeof record.Name === 'string' ? record.Name : '',
				args: splitCommandLine(
					typeof record.CommandLine === 'string' ? record.CommandLine : '',
				),
			});
		}
		return found;
	}

	const result = Bun.spawnSync({
		cmd: ['ps', '-p', wanted.join(','), '-o', 'pid=,ppid=,comm=,args='],
		stdout: 'pipe',
		stderr: 'pipe',
	});
	if (result.exitCode !== 0) return found;
	for (const line of result.stdout.toString().split('\n')) {
		const match = line.trim().match(/^(\d+)\s+(\d+)\s+(\S+)\s+([\s\S]*)$/);
		if (!match) continue;
		const pid = Number(match[1]);
		found.set(pid, {
			pid,
			ppid: Number(match[2]),
			name: match[3] ?? '',
			args: splitCommandLine(match[4] ?? ''),
		});
	}
	return found;
}

async function readOwner(slug: string): Promise<ProcessOwner | undefined> {
	try {
		return parseOwner(
			await readFile(join(runtimePath(slug), 'session.lock', 'owner.json'), 'utf8'),
		);
	} catch (error: unknown) {
		if (missing(error)) return undefined;
		throw error;
	}
}

const entries = await listAgentSlugs();

const rows: { name: string; provider: string; status: string; detail: string }[] = [];
const hibernated = new Set<string>();
for (const slug of entries) {
	let record: Awaited<ReturnType<typeof loadAgent>>;
	try {
		record = await loadAgent(slug);
	} catch (error: unknown) {
		rows.push({
			name: slug,
			provider: '',
			status: 'unreadable',
			detail: error instanceof Error ? error.message : String(error),
		});
		continue;
	}
	if (!record) continue;
	if (record.hibernation?.active) hibernated.add(record.name);
	const owner = await readOwner(slug);
	if (!owner) {
		rows.push({
			name: record.name,
			provider: record.provider,
			status: 'offline',
			detail: 'no session lock',
		});
		continue;
	}
	const info = processes([owner.pid, owner.childPid ?? 0]);
	const runner = info.get(owner.pid);
	if (
		!runner ||
		!sessionArg(runner.args, slug) ||
		!['bun', 'node'].includes(program(runner.name))
	) {
		rows.push({
			name: record.name,
			provider: record.provider,
			status: 'stale',
			detail: runner
				? `lock pid ${owner.pid} is ${runner.name}, not the summon session for ${slug}`
				: `lock pid ${owner.pid} is not running`,
		});
		continue;
	}
	const parentInfo = processes([runner.ppid]);
	const parent = parentInfo.get(runner.ppid);
	if (!parent || !isSessionHost(parent.name)) {
		rows.push({
			name: record.name,
			provider: record.provider,
			status: 'unhosted',
			detail: parent
				? `session parent is ${parent.name}, not a terminal or shell`
				: 'session parent is not running',
		});
		continue;
	}
	const child = owner.childPid === undefined ? undefined : info.get(owner.childPid);
	if (!child || child.ppid !== owner.pid || program(child.name) !== record.provider) {
		rows.push({
			name: record.name,
			provider: record.provider,
			status: 'provider-missing',
			detail: child
				? `provider process is ${child.name} and its parent is ${child.ppid}`
				: 'provider process is not running',
		});
		continue;
	}
	rows.push({
		name: record.name,
		provider: record.provider,
		status: 'online',
		detail: program(parent.name) === 'electron' ? 'summon team window' : parent.name,
	});
}

if (rows.length === 0) console.log(`No registered agents in ${storageRoot() || homedir()}.`);
for (const row of rows) {
	const status = hibernated.has(row.name) ? 'hibernated' : row.status;
	const detail = hibernated.has(row.name) ? `${row.status}; ${row.detail}` : row.detail;
	console.log(`${row.name}\t${row.provider}\t${status}\t${detail}`);
}
